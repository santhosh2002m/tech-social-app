"use strict";
exports.id = 4692;
exports.ids = [4692];
exports.modules = {

/***/ 74692:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ common_Contact)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./public/images/avatar-1.png
var avatar_1 = __webpack_require__(30954);
// EXTERNAL MODULE: ./public/images/avatar-2.png
var avatar_2 = __webpack_require__(87041);
// EXTERNAL MODULE: ./public/images/avatar-3.png
var avatar_3 = __webpack_require__(67048);
// EXTERNAL MODULE: ./public/images/avatar-4.png
var avatar_4 = __webpack_require__(46387);
// EXTERNAL MODULE: ./public/images/avatar-5.png
var avatar_5 = __webpack_require__(22354);
// EXTERNAL MODULE: ./public/images/avatar-6.png
var avatar_6 = __webpack_require__(20474);
// EXTERNAL MODULE: ./public/images/avatar-7.png
var avatar_7 = __webpack_require__(21145);
// EXTERNAL MODULE: ./public/images/avatar-8.png
var avatar_8 = __webpack_require__(89530);
// EXTERNAL MODULE: ./public/images/avatar-9.png
var avatar_9 = __webpack_require__(53543);
;// CONCATENATED MODULE: ./data/contentData.ts









const contentData = [
    {
        id: 1,
        name: "Piter Maio",
        avt: avatar_2["default"]
    },
    {
        id: 2,
        name: "Floyd Miles",
        avt: avatar_1["default"]
    },
    {
        id: 3,
        name: "Darrell Steward",
        avt: avatar_3["default"]
    },
    {
        id: 4,
        name: "Kristin Watson",
        avt: avatar_4["default"]
    },
    {
        id: 5,
        name: "Jane Cooper",
        avt: avatar_5["default"]
    },
    {
        id: 6,
        name: "Devon Lane",
        avt: avatar_6["default"]
    },
    {
        id: 7,
        name: "Annette Black",
        avt: avatar_7["default"]
    },
    {
        id: 8,
        name: "Jerome Bell",
        avt: avatar_8["default"]
    },
    {
        id: 9,
        name: "Guy Hawkins",
        avt: avatar_9["default"]
    }
];
/* harmony default export */ const data_contentData = (contentData);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./components/ui/ContactAction.tsx
var ContactAction = __webpack_require__(33529);
;// CONCATENATED MODULE: ./components/common/SingleContact.tsx
// SingleContact.tsx




const SingleContact = ({ data , sectionType  })=>{
    const { avt , id , name  } = data;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "avatar-item d-flex gap-3 align-items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "avatar-item",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "avatar-img max-un",
                            src: avt,
                            alt: "avatar"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "info-area",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            className: "m-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/public-profile/post",
                                className: "mdtxt",
                                children: name
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ContactAction/* default */.Z, {
                sectionType: sectionType
            })
        ]
    });
};
/* harmony default export */ const common_SingleContact = (SingleContact);

;// CONCATENATED MODULE: ./components/common/Contact.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 






const Contact = ({ children , sectionType  })=>{
    const pathname = (0,navigation.usePathname)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            children,
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "d-flex flex-column gap-6",
                children: [
                    pathname === "/" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "profile-area d-center position-relative align-items-center justify-content-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "avatar-item d-flex gap-3 align-items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "avatar-item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "avatar-img max-un",
                                            src: avatar_6["default"],
                                            alt: "avatar"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "info-area",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            className: "m-0",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/public-profile/post",
                                                className: "mdtxt",
                                                children: "Piter Maio"
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "mdtxt abs-area d-center position-absolute end-0",
                                children: "5"
                            })
                        ]
                    }),
                    data_contentData?.map((itm)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "profile-area d-center justify-content-between",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(common_SingleContact, {
                                data: itm,
                                sectionType: sectionType
                            })
                        }, itm.id))
                ]
            })
        ]
    });
};
/* harmony default export */ const common_Contact = (Contact);


/***/ }),

/***/ 89530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-8.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 53543:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-9.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ })

};
;