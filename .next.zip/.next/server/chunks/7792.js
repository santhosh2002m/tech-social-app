"use strict";
exports.id = 7792;
exports.ids = [7792];
exports.modules = {

/***/ 9571:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62208);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42585);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_ContactAction__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38445);
// EventCard.tsx




const EventCard = ({ data  })=>{
    const { id , img , place , published , title  } = data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "single-box p-5",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "avatar-box position-relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "avatar-img w-100",
                        src: img,
                        alt: "avatar"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "abs-area w-100 position-absolute top-0 p-3 d-center justify-content-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "date-area mdtxt",
                                children: published
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_ContactAction__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                sectionType: "followings"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                href: `/event/${id}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                    className: "m-0 mt-4",
                    children: title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "smtxt city-area",
                children: place
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-center gap-2 mt-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "cmn-btn",
                        children: "interested"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "cmn-btn alt third",
                        children: "Share"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EventCard);


/***/ }),

/***/ 34185:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ data_eventData)
});

;// CONCATENATED MODULE: ./public/images/event-img-1.png
/* harmony default export */ const event_img_1 = ({"src":"/_next/static/media/event-img-1.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-2.png
/* harmony default export */ const event_img_2 = ({"src":"/_next/static/media/event-img-2.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-3.png
/* harmony default export */ const event_img_3 = ({"src":"/_next/static/media/event-img-3.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-4.png
/* harmony default export */ const event_img_4 = ({"src":"/_next/static/media/event-img-4.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-5.png
/* harmony default export */ const event_img_5 = ({"src":"/_next/static/media/event-img-5.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-6.png
/* harmony default export */ const event_img_6 = ({"src":"/_next/static/media/event-img-6.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-7.png
/* harmony default export */ const event_img_7 = ({"src":"/_next/static/media/event-img-7.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-8.png
/* harmony default export */ const event_img_8 = ({"src":"/_next/static/media/event-img-8.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/event-img-9.png
/* harmony default export */ const event_img_9 = ({"src":"/_next/static/media/event-img-9.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./data/eventData.ts









const eventData = [
    {
        id: 1,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_1
    },
    {
        id: 2,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_2
    },
    {
        id: 3,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_3
    },
    {
        id: 4,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_4
    },
    {
        id: 5,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_5
    },
    {
        id: 6,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_6
    },
    {
        id: 7,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_7
    },
    {
        id: 8,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_8
    },
    {
        id: 9,
        title: "Martio Music Event I Biggest Music Festival",
        published: "2 DEC 2022",
        place: "Alaska,CA",
        img: event_img_9
    }
];
/* harmony default export */ const data_eventData = (eventData);


/***/ }),

/***/ 14352:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-1.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 91504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-2.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 86406:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-3.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 50951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-4.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 56833:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-5.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 61688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-6.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 99820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-7.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 56440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-8.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 89628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-img-9.8e963edb.png","height":200,"width":266,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXv7+/19fXt7e3g4ODDw8PU1NTbgSuOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNgggIGJgZGRgZGBiYGBmYWVlYWZgYwgxnEgEvBFAMACfUAXd6/aaAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ })

};
;