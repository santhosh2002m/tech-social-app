exports.id = 2160;
exports.ids = [2160];
exports.modules = {

/***/ 76121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ common_ProductDetails)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var lib = __webpack_require__(17738);
// EXTERNAL MODULE: ./public/images/marketplace-img-1.png
var marketplace_img_1 = __webpack_require__(79117);
// EXTERNAL MODULE: ./public/images/marketplace-img-2.png
var marketplace_img_2 = __webpack_require__(80063);
// EXTERNAL MODULE: ./public/images/marketplace-img-3.png
var marketplace_img_3 = __webpack_require__(88838);
// EXTERNAL MODULE: ./public/images/marketplace-img-4.png
var marketplace_img_4 = __webpack_require__(24958);
// EXTERNAL MODULE: ./public/images/marketplace-img-5.png
var marketplace_img_5 = __webpack_require__(16313);
// EXTERNAL MODULE: ./public/images/marketplace-img-6.png
var marketplace_img_6 = __webpack_require__(82254);
;// CONCATENATED MODULE: ./components/sliders/ProductSlider.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 









const ProductSlider = ()=>{
    const [nav1, setNav1] = (0,react_.useState)();
    const [nav2, setNav2] = (0,react_.useState)();
    const settings = {
        infinite: false,
        autoplay: false,
        centerMode: false,
        centerPadding: "0px 50px",
        focusOnSelect: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        dots: false,
        dotsClass: "section-dots"
    };
    const settingsTwo = {
        slidesToShow: 3,
        slidesToScroll: 1,
        dots: false,
        centerMode: true,
        focusOnSelect: true,
        responsive: [
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 3,
                    arrows: false
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    arrows: false
                }
            }
        ]
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(lib/* default */.Z, {
                ...settings,
                asNavFor: nav2,
                ref: (slider1)=>setNav1(slider1),
                className: "slider-for",
                children: [
                    marketplace_img_1["default"],
                    marketplace_img_2["default"],
                    marketplace_img_3["default"],
                    marketplace_img_4["default"],
                    marketplace_img_5["default"],
                    marketplace_img_6["default"]
                ].map((itm, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-slide",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: itm,
                            alt: "avatar"
                        })
                    }, i))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(lib/* default */.Z, {
                ...settingsTwo,
                asNavFor: nav1,
                ref: (slider2)=>setNav2(slider2),
                slidesToShow: 3,
                swipeToSlide: true,
                focusOnSelect: true,
                className: "slider-nav",
                children: [
                    marketplace_img_1["default"],
                    marketplace_img_2["default"],
                    marketplace_img_3["default"],
                    marketplace_img_4["default"],
                    marketplace_img_5["default"],
                    marketplace_img_6["default"]
                ].map((itm, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-slide",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "slide",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: itm,
                                alt: "avatar"
                            })
                        })
                    }, i))
            })
        ]
    });
};
/* harmony default export */ const sliders_ProductSlider = (ProductSlider);

;// CONCATENATED MODULE: ./components/common/ProductDetails.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 


const ProductDetails = ({ children  })=>{
    const [product, setProduct] = (0,react_.useState)(1);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "shop-details-content",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row justify-content-center align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-md-8",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(sliders_ProductSlider, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-md-8 mt-7 mt-xl-0",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        children: "Digital Camera"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "star-item my-4 d-flex gap-2 align-items-center",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "star-area",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fas fa-star"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fas fa-star"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fas fa-star"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fas fa-star"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fas fa-star"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "mdr",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "(534 ratings)"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Product Id: 08.01.028.48"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "price-area d-flex my-4 gap-3 align-items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "cur-price",
                                                children: "$49.00"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("del", {
                                                    children: "$70.00"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "description",
                                        children: [
                                            "Aliquam luctus, nibh quis scelerisque scelerisque, purus magna sollicitudin magna, quis cursus nunc tellus eget nisi.",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "single-input cart-content my-4",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "d-flex gap-3",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "qtySelector px-4 px-3 d-inline-flex align-items-center text-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-minus d-center decreaseQty",
                                                        onClick: ()=>setProduct((prev)=>prev <= 1 ? prev : prev - 1)
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        className: "qtyValue text-center m-0 xxltxt",
                                                        value: product,
                                                        onChange: (e)=>setProduct(+e.target.value)
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fas fa-plus d-center increaseQty",
                                                        onClick: ()=>setProduct((prev)=>prev + 1)
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "cmn-btn w-100 text-center d-flex justify-content-center",
                                        children: "Add To Cart"
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "product-about mt-60",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-9",
                        children: children
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const common_ProductDetails = (ProductDetails);


/***/ }),

/***/ 37742:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/ProductDetails.tsx");


/***/ }),

/***/ 95244:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// components/menu/HomeLeft.tsx
/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/menu/HomeLeft.tsx");


/***/ })

};
;