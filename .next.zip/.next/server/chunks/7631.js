exports.id = 7631;
exports.ids = [7631];
exports.modules = {

/***/ 46529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ common_ProfileBanner)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./components/ui/ContactAction.tsx
var ContactAction = __webpack_require__(33529);
;// CONCATENATED MODULE: ./public/images/avatar-14.png
/* harmony default export */ const avatar_14 = ({"src":"/_next/static/media/avatar-14.d1c0d461.png","height":120,"width":120,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAADFBMVEXw8PDt7e3Q0NDb29sWvrQaAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAIUlEQVR4nGNghAIGBIMBDBgZGBiZmJiZmEFsKAMuhaELAAj1AD/BkUeCAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./public/images/avatar-2.png
var avatar_2 = __webpack_require__(87041);
// EXTERNAL MODULE: ./public/images/avatar-3.png
var avatar_3 = __webpack_require__(67048);
// EXTERNAL MODULE: ./public/images/avatar-4.png
var avatar_4 = __webpack_require__(46387);
;// CONCATENATED MODULE: ./public/images/profile-cover-img.png
/* harmony default export */ const profile_cover_img = ({"src":"/_next/static/media/profile-cover-img.4c5f2f02.png","height":300,"width":1236,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAD1BMVEXOzs7v7+/FxcXd3d3X19eLtEGaAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAFUlEQVR4nGNgZGZiYGFgYGSAMJgYAQDtABkYihHXAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./components/common/ProfileBanner.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 









const ProfileBanner = ({ tabData  })=>{
    const path = (0,navigation.usePathname)();
    const slugs = path.split("/");
    const lastPath = slugs[slugs.length - 1];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "single-box p-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "avatar-area",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "avatar-img w-100",
                    src: profile_cover_img,
                    alt: "image"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "top-area py-4 d-center flex-wrap gap-3 justify-content-between align-items-start",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "d-flex gap-3 align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "avatar-item p",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "avatar-img max-un",
                                    src: avatar_14,
                                    alt: "avatar"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-area text-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: "m-0 mb-2",
                                        children: "Lerio Mao"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "friends-list d-flex flex-wrap gap-2 align-items-center text-center",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                className: "d-flex align-items-center justify-content-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: avatar_3["default"],
                                                            alt: "image"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: avatar_2["default"],
                                                            alt: "image"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: avatar_4["default"],
                                                            alt: "image"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mdtxt d-center",
                                                children: "10k Followers"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mdtxt d-center following",
                                                children: "200 Following"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "btn-item d-center gap-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "URL:void()",
                                className: "cmn-btn d-center gap-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon fs-4",
                                        children: "person_add"
                                    }),
                                    "Follow"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "URL:void()",
                                className: "cmn-btn d-center gap-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon fs-4",
                                        children: "send"
                                    }),
                                    "Message"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ContactAction/* default */.Z, {
                                sectionType: "followings",
                                actionList: [
                                    [
                                        "Block",
                                        "lock"
                                    ],
                                    [
                                        "Report",
                                        "flag"
                                    ]
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "page-details",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "nav mt-5 pt-4 flex-wrap gap-2 tab-area",
                    children: tabData.map(([itm, slug, url], i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item",
                            role: "presentation",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                // href="/marketplace/post"
                                href: url,
                                className: `nav-link d-center ${lastPath === slug ? "active" : ""} `,
                                children: itm
                            })
                        }, i))
                })
            })
        ]
    });
};
/* harmony default export */ const common_ProfileBanner = (ProfileBanner);


/***/ }),

/***/ 38713:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/Contact.tsx");


/***/ }),

/***/ 38022:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/ProfileBanner.tsx");


/***/ })

};
;