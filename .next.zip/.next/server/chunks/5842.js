"use strict";
exports.id = 5842;
exports.ids = [5842];
exports.modules = {

/***/ 50855:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62208);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42585);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



const ProductCard = ({ data  })=>{
    const { author_img , author_name , brand , id , img , name , price  } = data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "single-box marketplace-item p-2 p-sm-5",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "avatar-area position-relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "avatar-img w-100",
                        src: img,
                        alt: "avatar"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                        className: "position-absolute price-box",
                        children: [
                            "$",
                            price
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "info-box mt-12 text-start",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/marketplace/${id}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: name
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "head-area mt-5 d-flex justify-content-between",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "d-flex w-100 gap-3 align-items-center justify-content-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "d-flex gap-3 align-items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "avatar-item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        className: "avatar-img max-un",
                                        src: author_img,
                                        alt: "avatar"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-area text-start",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: "m-0 mb-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/public-profile/post",
                                                children: author_name
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mdtxt",
                                            children: brand
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "star-area",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "fas fa-star"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "fas fa-star"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "fas fa-star"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "fas fa-star"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "fas fa-star"
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCard);


/***/ }),

/***/ 35123:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ data_productData)
});

;// CONCATENATED MODULE: ./public/images/marketplace-img-1.png
/* harmony default export */ const marketplace_img_1 = ({"src":"/_next/static/media/marketplace-img-1.d11ec65c.png","height":350,"width":450,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXx8fHu7u7Gxsbf39/X19f19fU/xWfOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAI0lEQVR4nGNghAIGRgZWBgZWBkYGBmYmFhYmZgYEAy4FUwwACDoATSDShJgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/marketplace-img-2.png
/* harmony default export */ const marketplace_img_2 = ({"src":"/_next/static/media/marketplace-img-2.d11ec65c.png","height":350,"width":450,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXx8fHu7u7Gxsbf39/X19f19fU/xWfOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAI0lEQVR4nGNghAIGRgZWBgZWBkYGBmYmFhYmZgYEAy4FUwwACDoATSDShJgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/marketplace-img-3.png
/* harmony default export */ const marketplace_img_3 = ({"src":"/_next/static/media/marketplace-img-3.d11ec65c.png","height":350,"width":450,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXx8fHu7u7Gxsbf39/X19f19fU/xWfOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAI0lEQVR4nGNghAIGRgZWBgZWBkYGBmYmFhYmZgYEAy4FUwwACDoATSDShJgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/marketplace-img-4.png
/* harmony default export */ const marketplace_img_4 = ({"src":"/_next/static/media/marketplace-img-4.d11ec65c.png","height":350,"width":450,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXx8fHu7u7Gxsbf39/X19f19fU/xWfOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAI0lEQVR4nGNghAIGRgZWBgZWBkYGBmYmFhYmZgYEAy4FUwwACDoATSDShJgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/marketplace-img-5.png
/* harmony default export */ const marketplace_img_5 = ({"src":"/_next/static/media/marketplace-img-5.d11ec65c.png","height":350,"width":450,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXx8fHu7u7Gxsbf39/X19f19fU/xWfOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAI0lEQVR4nGNghAIGRgZWBgZWBkYGBmYmFhYmZgYEAy4FUwwACDoATSDShJgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/marketplace-img-6.png
/* harmony default export */ const marketplace_img_6 = ({"src":"/_next/static/media/marketplace-img-6.d11ec65c.png","height":350,"width":450,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAElBMVEXx8fHu7u7Gxsbf39/X19f19fU/xWfOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAI0lEQVR4nGNghAIGRgZWBgZWBkYGBmYmFhYmZgYEAy4FUwwACDoATSDShJgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./public/images/page-avatar-1.png
var page_avatar_1 = __webpack_require__(42307);
;// CONCATENATED MODULE: ./data/productData.ts







const productData = [
    {
        id: 1,
        name: "Men's Watch",
        price: 49,
        img: marketplace_img_1,
        author_name: "Travel Moon",
        author_img: page_avatar_1/* default */.Z,
        brand: "Zara"
    },
    {
        id: 2,
        name: "Digital Camera",
        price: 49,
        img: marketplace_img_2,
        author_name: "Travel Moon",
        author_img: page_avatar_1/* default */.Z,
        brand: "Zara"
    },
    {
        id: 3,
        name: "Laptop",
        price: 49,
        img: marketplace_img_3,
        author_name: "Travel Moon",
        author_img: page_avatar_1/* default */.Z,
        brand: "Zara"
    },
    {
        id: 4,
        name: "Schoolchild Backpack",
        price: 49,
        img: marketplace_img_4,
        author_name: "Travel Moon",
        author_img: page_avatar_1/* default */.Z,
        brand: "Zara"
    },
    {
        id: 5,
        name: "Women Heeled Shoes",
        price: 49,
        img: marketplace_img_5,
        author_name: "Travel Moon",
        author_img: page_avatar_1/* default */.Z,
        brand: "Zara"
    },
    {
        id: 6,
        name: "Headphone",
        price: 49,
        img: marketplace_img_6,
        author_name: "Travel Moon",
        author_img: page_avatar_1/* default */.Z,
        brand: "Zara"
    }
];
/* harmony default export */ const data_productData = (productData);


/***/ }),

/***/ 63881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/node_modules/next/dist/client/image.js");
 //# sourceMappingURL=image.js.map


/***/ }),

/***/ 42301:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/node_modules/next/dist/client/link.js");
 //# sourceMappingURL=link.js.map


/***/ }),

/***/ 62208:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


module.exports = __webpack_require__(63881);


/***/ }),

/***/ 42585:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


module.exports = __webpack_require__(42301);


/***/ }),

/***/ 31542:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/page-avatar-1.d9aa7c6b.png","height":57,"width":57,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAFVBMVEXz8/Pt7e3u7u7MzMzCwsLc3Nzk5ORak1u8AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAALElEQVR4nD2LQQ4AIAyDoJv//7JRFzmR0JKBRPUKgCF2dSGxVq0jP8XM+N03D40AbnlA0gcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 42307:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/page-avatar-1.d9aa7c6b.png","height":57,"width":57,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAFVBMVEXz8/Pt7e3u7u7MzMzCwsLc3Nzk5ORak1u8AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAALElEQVR4nD2LQQ4AIAyDoJv//7JRFzmR0JKBRPUKgCF2dSGxVq0jP8XM+N03D40AbnlA0gcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ })

};
;