exports.id = 247;
exports.ids = [247];
exports.modules = {

/***/ 76882:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16294))

/***/ }),

/***/ 27739:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 78301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 83751, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 54765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5192, 23))

/***/ }),

/***/ 26742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ axiosCall)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3679);
/* harmony import */ var react_secure_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65673);


const API_URL = "https://dev.techsocial.ai/api/web/index.php";
const VERSION = "v1";
async function axiosCall({ ENDPOINT , METHOD , PAYLOAD , CONFIG =false  }) {
    const headers = {
        Accept: "application/json"
    };
    if (CONFIG) {
        headers["Content-Type"] = "multipart/form-data";
        headers["Accept"] = "*/*";
    } else {
        headers["Content-Type"] = "application/json;charset=UTF-8";
    }
    const options = {
        method: METHOD,
        url: `${API_URL}/${VERSION}/${ENDPOINT}`,
        data: PAYLOAD,
        headers
    };
    const token = react_secure_storage__WEBPACK_IMPORTED_MODULE_0__/* ["default"].getItem */ .Z.getItem("loginToken") || null;
    if (token !== null) {
        options.headers = {
            ...options.headers,
            Authorization: `Bearer ${token}`
        };
    }
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].request */ .Z.request(options);
        return response;
    } catch (error) {
        if (error.response?.status === 401) {
            react_secure_storage__WEBPACK_IMPORTED_MODULE_0__/* ["default"].removeItem */ .Z.removeItem("loginToken");
            throw new Error("Session expired. Please log in again.");
        }
        throw error;
    }
}


/***/ }),

/***/ 16294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
// EXTERNAL MODULE: ./node_modules/next-themes/dist/index.js
var dist = __webpack_require__(95176);
// EXTERNAL MODULE: ./data/messageData.ts
var messageData = __webpack_require__(63155);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/common/Message.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 



const Message = ({ activeHandler  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "messages-btn cmn-head",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "icon-area d-center position-relative",
                    onClick: ()=>activeHandler("message"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "material-symbols-outlined mat-icon",
                            children: "mail"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "abs-area position-absolute d-center mdtxt",
                            children: "4"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "main-area p-5 messages-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "mb-8",
                        children: "Messages"
                    }),
                    messageData/* default.map */.Z.map((message)=>{
                        const { clss , id , last_message , number_of_message , user_avt , user_name  } = message;
                        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "single-box p-0 mb-7",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/profile/chat",
                                className: "d-flex gap-2 align-items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "avatar",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "avatar-img max-un",
                                            src: user_avt,
                                            alt: "avatar"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-area",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "title-area position-relative d-inline-flex align-items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                        className: "m-0 d-inline-flex",
                                                        children: user_name
                                                    }),
                                                    number_of_message && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "abs-area position-absolute d-center mdtxt",
                                                        children: number_of_message
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: `mdtxt ${clss}`,
                                                children: last_message
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, id);
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "btn-area",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/profile/chat",
                            children: "See all inbox"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const common_Message = (Message);

// EXTERNAL MODULE: ./public/images/avatar-1.png
var avatar_1 = __webpack_require__(30954);
// EXTERNAL MODULE: ./public/images/avatar-2.png
var avatar_2 = __webpack_require__(87041);
// EXTERNAL MODULE: ./public/images/avatar-3.png
var avatar_3 = __webpack_require__(67048);
// EXTERNAL MODULE: ./public/images/avatar-4.png
var avatar_4 = __webpack_require__(46387);
;// CONCATENATED MODULE: ./public/images/icon/emoji-love.png
/* harmony default export */ const emoji_love = ({"src":"/_next/static/media/emoji-love.99cd9f34.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAVFBMVEXqw1vz0W7002bLQTL00XDvwVv30Wb11XHwx11MaXHwsWO1nVf0xl3uxFvloVT/5XLyuFvmbUf/22fQTTfRmVN9T0//1GPNuV3HHijNuV7HHifloFTL131wAAAAD3RSTlMrLf75srDp8/YA/vnorf6xrZ7GAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAQklEQVR4nAXBCQKAIAgEwFVRQCs8O///z2agjpgJCsfmvSWAWji+0CJ4vLXeQ8Ayr2dWAVlZq/QIpJ7zuQGKKLJDf1qEAqZzLAlkAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/speech-bubble.png
/* harmony default export */ const speech_bubble = ({"src":"/_next/static/media/speech-bubble.7c25cab7.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAARVBMVEX/yzL/00v2tCX1qxn+xzL/2Fj2tydMaXH8uiH/2FT5vSj/22T5uSf/AAD90U//ySr+2GL62ID41HT/1jvx1JXt1qv/0DedUiPoAAAAD3RSTlP+91Vp/f2hAP7y/NbgAZdHyCsuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAQElEQVR4nBXJWRYAEQwEwEaTMFvEcv+jzlO/hcss5zBu1O9AQ7Xu3k0R+ppzuaKSAE+NTe7REFOhlhQhj7xFRH5nqgKbQvq0XQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/common/Notification.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 








const Notification = ({ activeHandler  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "notification-btn cmn-head position-relative",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "icon-area d-center position-relative",
                    onClick: ()=>activeHandler("notification"),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "material-symbols-outlined mat-icon",
                            children: "notifications"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "abs-area position-absolute d-center mdtxt",
                            children: "3"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "main-area p-5 notification-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "mb-8",
                        children: "Notification"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-box p-0 mb-7",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/profile/notification",
                            className: "d-flex justify-content-between align-items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "left-item position-relative d-inline-flex gap-3",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "avatar position-relative d-inline-flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "avatar-img max-un",
                                                    src: avatar_1["default"],
                                                    alt: "avatar"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "abs-item position-absolute max-un",
                                                    src: speech_bubble,
                                                    alt: "icon"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-area",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "m-0 mb-1",
                                                    children: "Piter Maio"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "mdtxt",
                                                    children: "Comment on your post"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "time-remaining",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mdtxt",
                                        children: "Just now"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-box p-0 mb-7",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/profile/notification",
                            className: "d-flex justify-content-between align-items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "left-item position-relative d-inline-flex gap-3",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "avatar position-relative d-inline-flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "avatar-img max-un",
                                                    src: avatar_2["default"],
                                                    alt: "avatar"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "abs-item position-absolute max-un",
                                                    src: emoji_love,
                                                    alt: "icon"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-area",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "m-0 mb-1",
                                                    children: "Kathryn Murphy"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "mdtxt",
                                                    children: "Like your photo"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "time-remaining",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mdtxt",
                                        children: "2min"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "single-box p-0 mb-7",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/profile/notification",
                                className: "d-flex justify-content-between align-items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "left-item position-relative d-inline-flex gap-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "avatar position-relative d-inline-flex",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        className: "avatar-img max-un",
                                                        src: avatar_3["default"],
                                                        alt: "avatar"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        className: "abs-item position-absolute max-un",
                                                        src: emoji_love,
                                                        alt: "icon"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "text-area",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                        className: "m-0 mb-1",
                                                        children: "Jacob Jones"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mdtxt",
                                                        children: "Sent you a request"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "time-remaining",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mdtxt",
                                            children: "1hr"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex gap-3 mt-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "cmn-btn",
                                        children: "Accept"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "cmn-btn alt",
                                        children: "Delete"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-box p-0 mb-7",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/profile/notification",
                            className: "d-flex justify-content-between align-items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "left-item position-relative d-inline-flex gap-3",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "avatar position-relative d-inline-flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "avatar-img max-un",
                                                    src: avatar_4["default"],
                                                    alt: "avatar"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    className: "abs-item position-absolute max-un",
                                                    src: emoji_love,
                                                    alt: "icon"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-area",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "m-0 mb-1",
                                                    children: "Kathryn Murphy"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "mdtxt",
                                                    children: "officia consequat duis enim..."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "time-remaining",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mdtxt",
                                        children: "2hr"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "btn-area",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/profile/notification",
                            children: "See all notification"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const common_Notification = (Notification);

// EXTERNAL MODULE: ./public/images/hell.jpg
var hell = __webpack_require__(6670);
;// CONCATENATED MODULE: ./components/common/Setting.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 





const Setting = ({ activeHandler  })=>{
    const [enabled, setEnabled] = (0,react_.useState)(false);
    const { theme , setTheme  } = (0,dist/* useTheme */.F)();
    const handleTheme = ()=>{
        setTheme(theme === "dark" || theme === "system" ? "light" : "dark");
    };
    (0,react_.useEffect)(()=>setEnabled(true), []);
    if (!enabled) return null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "profile-pic d-flex align-items-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "avatar cmn-head active-status",
                    onClick: ()=>activeHandler("settings"),
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: "avatar-img max-un setting-size",
                        src: hell/* default */.Z,
                        alt: "avatar"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "main-area p-5 profile-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "head-area",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "d-flex gap-3 align-items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "avatar-item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "avatar-img max-un setting-size",
                                        src: hell/* default */.Z,
                                        alt: "avatar"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-area",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            className: "m-0 mb-1",
                                            children: "Lori Ferguson"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mdtxt",
                                            children: "Web Developer"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "view-profile my-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/profile/post",
                            className: "mdtxt w-100 text-center py-2",
                            children: "View profile"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/#",
                                className: "mdtxt",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "power_settings_new"
                                    }),
                                    "Sign Out"
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const common_Setting = (Setting);

;// CONCATENATED MODULE: ./components/menu/BottomMenu.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 




const BottomMenu = ()=>{
    const [active, setActive] = (0,react_.useState)("");
    const activeHandler = (opt)=>{
        if (opt === active) {
            setActive("");
        } else {
            setActive(opt);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "header-menu py-3 header-menu d-block d-lg-none position-fixed bottom-0 w-100 cus-z",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "right-area position-relative d-flex justify-content-around gap-3 gap-xxl-6 align-items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `single-item messages-area ${active === "message" ? "active" : ""}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(common_Message, {
                        activeHandler: activeHandler
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `single-item messages-area notification-area ${active === "notification" ? "active" : ""}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(common_Notification, {
                        activeHandler: activeHandler
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `single-item profile-area position-relative ${active === "settings" ? "active" : ""}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(common_Setting, {
                        activeHandler: activeHandler
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const menu_BottomMenu = (BottomMenu);

// EXTERNAL MODULE: ./components/select/Select.tsx
var Select = __webpack_require__(6622);
// EXTERNAL MODULE: ./public/images/add-post-avatar.png
var add_post_avatar = __webpack_require__(7953);
;// CONCATENATED MODULE: ./components/modals/ActivityModal.tsx





const privacySelect = [
    {
        id: 1,
        name: "Public"
    },
    {
        id: 2,
        name: "Only Me"
    },
    {
        id: 3,
        name: "Friends"
    },
    {
        id: 4,
        name: "Custom"
    }
];
const ActivityModal = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "go-live-popup",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-lg-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "modal cmn-modal fade",
                        id: "activityMod",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "modal-dialog modal-dialog-centered",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-content p-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "modal-header justify-content-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: "btn-close",
                                            "data-bs-dismiss": "modal",
                                            "aria-label": "Close",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "material-symbols-outlined mat-icon xxltxt",
                                                children: "close"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "top-content pb-5",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "Create post"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mid-area",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex mb-5 gap-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "profile-box",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: add_post_avatar/* default */.Z,
                                                                className: "max-un",
                                                                alt: "icon"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                        cols: 10,
                                                        rows: 2,
                                                        placeholder: "Write something to Lerio.."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "file-upload",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        children: "Upload attachment"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        className: "file mt-1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "file"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "file-custom pt-8 pb-8 d-grid text-center",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "material-symbols-outlined mat-icon",
                                                                        children: "perm_media"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        children: "Drag here or click to upload photo."
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "tooltips-area d-flex mt-3 gap-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "button",
                                                        className: "btn d-center",
                                                        "data-bs-toggle": "tooltip",
                                                        "data-bs-placement": "top",
                                                        title: "Fallings/Activity",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "material-symbols-outlined mat-icon",
                                                            children: "mood"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "button",
                                                        className: "btn d-center",
                                                        "data-bs-toggle": "tooltip",
                                                        "data-bs-placement": "top",
                                                        title: "Video",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "material-symbols-outlined mat-icon",
                                                            children: "movie"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "button",
                                                        className: "btn d-center",
                                                        "data-bs-toggle": "tooltip",
                                                        "data-bs-placement": "top",
                                                        title: "Maps",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "material-symbols-outlined mat-icon",
                                                            children: "location_on"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "button",
                                                        className: "btn d-center",
                                                        "data-bs-toggle": "tooltip",
                                                        "data-bs-placement": "top",
                                                        title: "Tag",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "material-symbols-outlined mat-icon",
                                                            children: "sell"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-area d-flex justify-content-between pt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "left-area",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Select["default"], {
                                                    data: privacySelect
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "btn-area d-flex justify-content-end gap-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "button",
                                                        className: "cmn-btn alt",
                                                        "data-bs-dismiss": "modal",
                                                        "aria-label": "Close",
                                                        children: "Cancel"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "cmn-btn",
                                                        children: "Post"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const modals_ActivityModal = (ActivityModal);

;// CONCATENATED MODULE: ./components/modals/LiveModal.tsx




const LiveModal = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "go-live-popup",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-lg-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "modal cmn-modal fade",
                        id: "goLiveMod",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "modal-dialog modal-dialog-centered",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-content p-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "modal-header justify-content-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: "btn-close",
                                            "data-bs-dismiss": "modal",
                                            "aria-label": "Close",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "material-symbols-outlined mat-icon xxltxt",
                                                children: "close"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "top-content pb-5",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "Go Live"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mid-area",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex mb-5 gap-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "profile-box",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: add_post_avatar/* default */.Z,
                                                                className: "max-un",
                                                                alt: "icon"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                        cols: 10,
                                                        rows: 2,
                                                        placeholder: "Write something to Lerio.."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "file-upload",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        children: "Upload attachment"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        className: "file mt-1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "file"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "file-custom pt-8 pb-8 d-grid text-center",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "material-symbols-outlined mat-icon",
                                                                        children: "perm_media"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        children: "Drag here or click to upload photo."
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "footer-area pt-5",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "btn-area d-flex justify-content-end gap-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "button",
                                                    className: "cmn-btn alt",
                                                    "data-bs-dismiss": "modal",
                                                    "aria-label": "Close",
                                                    children: "Cancel"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "cmn-btn",
                                                    children: "Go Live"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const modals_LiveModal = (LiveModal);

;// CONCATENATED MODULE: ./components/modals/PhotoModal.tsx




const PhotoModal = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "go-live-popup video-popup",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-lg-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "modal cmn-modal fade",
                        id: "photoVideoMod",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "modal-dialog modal-dialog-centered",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-content p-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "modal-header justify-content-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            className: "btn-close",
                                            "data-bs-dismiss": "modal",
                                            "aria-label": "Close",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "material-symbols-outlined mat-icon xxltxt",
                                                children: "close"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "top-content pb-5",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "Add post photo/video"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mid-area",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex mb-5 gap-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "profile-box",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: add_post_avatar/* default */.Z,
                                                                className: "max-un",
                                                                alt: "icon"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                        cols: 10,
                                                        rows: 2,
                                                        placeholder: "Write something to Lerio.."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "file-upload",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        children: "Upload attachment"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        className: "file mt-1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                type: "file"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "file-custom pt-8 pb-8 d-grid text-center",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "material-symbols-outlined mat-icon",
                                                                        children: "perm_media"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        children: "Drag here or click to upload photo."
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "footer-area pt-5",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "btn-area d-flex justify-content-end gap-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "button",
                                                    className: "cmn-btn alt",
                                                    "data-bs-dismiss": "modal",
                                                    "aria-label": "Close",
                                                    children: "Cancel"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "cmn-btn",
                                                    children: "Post"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const modals_PhotoModal = (PhotoModal);

;// CONCATENATED MODULE: ./components/modals/PostPopups.tsx




const PostPopups_privacySelect = [
    {
        id: 1,
        name: "Public"
    },
    {
        id: 2,
        name: "Only Me"
    },
    {
        id: 3,
        name: "Friends"
    },
    {
        id: 4,
        name: "Custom"
    }
];
const PostPopups = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(modals_LiveModal, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(modals_PhotoModal, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(modals_ActivityModal, {})
        ]
    });
};
/* harmony default export */ const modals_PostPopups = (PostPopups);

// EXTERNAL MODULE: ./public/images/logo.png
var logo = __webpack_require__(59374);
;// CONCATENATED MODULE: ./components/navbar/NavBar.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 







const NavBar = ({ clss ="container"  })=>{
    const [windowHeight, setWindowHeight] = (0,react_.useState)(0);
    const [active, setActive] = (0,react_.useState)("");
    const [activeSearchForm, setActiveSearchForm] = (0,react_.useState)(false);
    const navBarTop = ()=>{
        if (window !== undefined) {
            let height = window.scrollY;
            setWindowHeight(height);
        }
    };
    const activeHandler = (opt)=>{
        if (opt === active) {
            setActive("");
        } else {
            setActive(opt);
        }
    };
    (0,react_.useEffect)(()=>{
        window.addEventListener("scroll", navBarTop);
        return ()=>{
            window.removeEventListener("scroll", navBarTop);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: `header-section header-menu ${windowHeight > 50 && "animated fadeInDown header-fixed"}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: "navbar navbar-expand-lg p-0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: clss,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    className: "navbar w-100 navbar-expand-lg justify-content-between",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            className: "navbar-brand",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: logo/* default */.Z,
                                className: "logo",
                                alt: "logo"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `search-form  ${activeSearchForm ? "active" : ""}`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                action: "#",
                                className: "Ts_searchBar input-area d-flex align-items-center",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        placeholder: "search",
                                        autoComplete: "off",
                                        className: "Ts_searchBar_input"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            width: "20",
                                            height: "20",
                                            viewBox: "0 0 48 48",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "20",
                                                    cy: "20",
                                                    r: "16",
                                                    stroke: "#F15A29",
                                                    strokeWidth: "4",
                                                    fill: "black"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("text", {
                                                    x: "13",
                                                    y: "25",
                                                    fontFamily: "Arial, sans-serif",
                                                    fontWeight: "bold",
                                                    fontSize: "14",
                                                    fill: "#F15A29",
                                                    children: "AI"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                                    x1: "31",
                                                    y1: "31",
                                                    x2: "44",
                                                    y2: "44",
                                                    stroke: "#F15A29",
                                                    strokeWidth: "4",
                                                    strokeLinecap: "round"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "right-area position-relative d-flex gap-3 gap-xxl-6 align-items-center left-side",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `single-item d-none d-lg-block messages-area ${active === "message" ? "active" : ""}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(common_Message, {
                                        activeHandler: activeHandler
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `single-item d-none d-lg-block messages-area notification-area ${active === "notification" ? "active" : ""}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(common_Notification, {
                                        activeHandler: activeHandler
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `single-item d-none d-lg-block profile-area position-relative ${active === "settings" ? "active" : ""}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(common_Setting, {
                                        activeHandler: activeHandler
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const navbar_NavBar = (NavBar);

;// CONCATENATED MODULE: ./components/preloader/Preloader.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 

const Preloader = ()=>{
    const [showLoader, setShowLoader] = (0,react_.useState)(true);
    const [isLoded, setIsLoded] = (0,react_.useState)(null);
    (0,react_.useEffect)(()=>{
        window.addEventListener("load", ()=>{
            setIsLoded("loaded");
        });
        const timer = setTimeout(()=>{
            setShowLoader(false);
        }, 1000);
        return ()=>clearTimeout(timer);
    }, []);
    return showLoader ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `preloader align-items-center justify-content-center ${isLoded}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
            className: "loader"
        })
    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
};
/* harmony default export */ const preloader_Preloader = (Preloader);

;// CONCATENATED MODULE: ./components/scrollToTop/ScrollToTop.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 

const ScrollToTop = ()=>{
    const [windowHeight, setWindowHeight] = (0,react_.useState)(0);
    const goToTopHandler = ()=>{
        window.scroll({
            top: 0,
            left: 0
        });
    };
    const goToTop = ()=>{
        if (window !== undefined) {
            let height = window.scrollY;
            setWindowHeight(height);
        }
    };
    (0,react_.useEffect)(()=>{
        window.addEventListener("scroll", goToTop);
        return ()=>{
            window.removeEventListener("scroll", goToTop);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: `scrollToTop d-none d-lg-block ${windowHeight > 200 && "active"}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
            className: "mat-icon fas fa-angle-double-up"
        })
    });
};
/* harmony default export */ const scrollToTop_ScrollToTop = (ScrollToTop);

// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs + 4 modules
var redux_toolkit_modern = __webpack_require__(62049);
// EXTERNAL MODULE: ./store/authSlice.tsx
var authSlice = __webpack_require__(76844);
// EXTERNAL MODULE: ./store/postSlice.ts
var postSlice = __webpack_require__(95239);
// EXTERNAL MODULE: ./store/userSlice.tsx
var userSlice = __webpack_require__(5331);
;// CONCATENATED MODULE: ./store/index.tsx




const store = (0,redux_toolkit_modern/* configureStore */.xC)({
    reducer: {
        auth: authSlice/* default */.ZP,
        posts: postSlice/* default */.ZP,
        user: userSlice/* default */.ZP
    }
});

// EXTERNAL MODULE: ./node_modules/react-modal-video/css/modal-video.css
var modal_video = __webpack_require__(42168);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(78217);
// EXTERNAL MODULE: ./styles/globals.scss
var globals = __webpack_require__(7837);
// EXTERNAL MODULE: ./styles/TS_styles.scss
var TS_styles = __webpack_require__(88944);
;// CONCATENATED MODULE: ./app/layout.tsx
// app/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 














function RootLayout({ children  }) {
    const pathname = (0,navigation.usePathname)();
    const isLoginPage = pathname === "/login";
    const clss = pathname !== "/index-two" ? "container" : "container-fluid";
    (0,react_.useEffect)(()=>{
        if (!isLoginPage) {
            __webpack_require__.e(/* import() */ 2944).then(__webpack_require__.t.bind(__webpack_require__, 62944, 23)).catch((err)=>console.error("Failed to load Bootstrap JS:", err));
        }
    }, [
        isLoginPage
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("head", {
                children: !isLoginPage && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "description",
                            content: "Circlehub React Nextjs Template"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("title", {
                            children: "TechSocial"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("body", {
                className: isLoginPage ? "login-page bg-color" : "app-page",
                children: /*#__PURE__*/ jsx_runtime_.jsx(lib.Provider, {
                    store: store,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* ThemeProvider */.f, {
                        attribute: "class",
                        enableSystem: false,
                        children: [
                            !isLoginPage && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(preloader_Preloader, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(scrollToTop_ScrollToTop, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(navbar_NavBar, {
                                        clss: clss
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(menu_BottomMenu, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(modals_PostPopups, {})
                                ]
                            }),
                            children
                        ]
                    })
                })
            })
        ]
    });
}


/***/ }),

/***/ 6622:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3841);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62189);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__  auto */ 


const Select = ({ data  })=>{
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data[0]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Listbox */ .R, {
        value: selected,
        onChange: setSelected,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "selector",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Listbox.Button */ .R.Button, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "",
                        children: selected?.name
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__/* .Transition */ .u, {
                    as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Listbox.Options */ .R.Options, {
                        children: data.map((itm)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Listbox.Option */ .R.Option, {
                                value: itm,
                                children: ({ selected  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: selected ? "selected fw-bold" : "",
                                        children: [
                                            itm.name,
                                            selected
                                        ]
                                    })
                            }, itm.id))
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Select);


/***/ }),

/***/ 63155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _public_images_avatar_1_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30954);
/* harmony import */ var _public_images_avatar_2_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87041);
/* harmony import */ var _public_images_avatar_3_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67048);
/* harmony import */ var _public_images_avatar_4_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46387);
/* harmony import */ var _public_images_avatar_5_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22354);
/* harmony import */ var _public_images_avatar_6_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20474);
/* harmony import */ var _public_images_avatar_7_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(21145);







const messageData = [
    {
        id: 1,
        user_name: "Piter Maio",
        user_avt: _public_images_avatar_7_png__WEBPACK_IMPORTED_MODULE_6__["default"],
        number_of_message: 3,
        last_message: "Amet minim mollit non....",
        clss: "sms"
    },
    {
        id: 2,
        user_name: "Annette Black",
        user_avt: _public_images_avatar_1_png__WEBPACK_IMPORTED_MODULE_0__["default"],
        number_of_message: null,
        last_message: "You: consequat sunt",
        clss: ""
    },
    {
        id: 3,
        user_name: "Ralph Edwards",
        user_avt: _public_images_avatar_2_png__WEBPACK_IMPORTED_MODULE_1__["default"],
        number_of_message: null,
        last_message: "You: consequat sunt",
        clss: "sms"
    },
    {
        id: 4,
        user_name: "Darrell Steward",
        user_avt: _public_images_avatar_3_png__WEBPACK_IMPORTED_MODULE_2__["default"],
        number_of_message: null,
        last_message: "You: consequat sunt",
        clss: ""
    },
    {
        id: 5,
        user_name: "Wade Warren",
        user_avt: _public_images_avatar_4_png__WEBPACK_IMPORTED_MODULE_3__["default"],
        number_of_message: null,
        last_message: "You: consequat sunt",
        clss: ""
    },
    {
        id: 6,
        user_name: "Kathryn Murphy",
        user_avt: _public_images_avatar_5_png__WEBPACK_IMPORTED_MODULE_4__["default"],
        number_of_message: null,
        last_message: "You: consequat sunt",
        clss: ""
    },
    {
        id: 7,
        user_name: "Jacob Jones",
        user_avt: _public_images_avatar_6_png__WEBPACK_IMPORTED_MODULE_5__["default"],
        number_of_message: null,
        last_message: "You: consequat sunt",
        clss: ""
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (messageData);


/***/ }),

/***/ 76844:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mu": () => (/* binding */ verifyOtp),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "a$": () => (/* binding */ registerUser),
/* harmony export */   "fw": () => (/* binding */ clearError),
/* harmony export */   "gF": () => (/* binding */ forgotPassword),
/* harmony export */   "pH": () => (/* binding */ loginUser)
/* harmony export */ });
/* unused harmony export logout */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62049);
/* harmony import */ var _api_APIcall__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(26742);
/* harmony import */ var react_secure_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65673);



const registerUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__/* .createAsyncThunk */ .hg)("auth/registerUser", async (userData, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "users/register",
            METHOD: "POST",
            PAYLOAD: userData
        });
        return response.data;
    } catch (error) {
        return rejectWithValue(error.message || "Failed to register user");
    }
});
const loginUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__/* .createAsyncThunk */ .hg)("auth/loginUser", async (credentials, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "users/login",
            METHOD: "POST",
            PAYLOAD: credentials
        });
        return response.data;
    } catch (error) {
        return rejectWithValue(error.message || "Failed to login");
    }
});
const verifyOtp = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__/* .createAsyncThunk */ .hg)("auth/verifyOtp", async ({ email , otp  }, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "users/verify-otp",
            METHOD: "POST",
            PAYLOAD: {
                email,
                otp
            }
        });
        return response.data;
    } catch (error) {
        return rejectWithValue(error.message || "Failed to verify OTP");
    }
});
const forgotPassword = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__/* .createAsyncThunk */ .hg)("auth/forgotPassword", async (email, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "users/forgot-password",
            METHOD: "POST",
            PAYLOAD: {
                email
            }
        });
        return response.data;
    } catch (error) {
        return rejectWithValue(error.message || "Failed to send password reset link");
    }
});
const initialState = {
    isAuthenticated: false,
    user: null,
    token: null,
    loading: false,
    error: null
};
const authSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__/* .createSlice */ .oM)({
    name: "auth",
    initialState,
    reducers: {
        clearError: (state)=>{
            state.error = null;
        },
        logout: (state)=>{
            state.isAuthenticated = false;
            state.user = null;
            state.token = null;
            react_secure_storage__WEBPACK_IMPORTED_MODULE_1__/* ["default"].removeItem */ .Z.removeItem("loginToken");
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(registerUser.pending, (state)=>{
            state.loading = true;
            state.error = null;
        });
        builder.addCase(registerUser.fulfilled, (state, action)=>{
            state.loading = false;
        });
        builder.addCase(registerUser.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Registration failed";
        });
        builder.addCase(loginUser.pending, (state)=>{
            state.loading = true;
            state.error = null;
        });
        builder.addCase(loginUser.fulfilled, (state, action)=>{
            state.loading = false;
            state.isAuthenticated = true;
            state.user = action.payload.data.user;
            state.token = action.payload.data.token;
            react_secure_storage__WEBPACK_IMPORTED_MODULE_1__/* ["default"].setItem */ .Z.setItem("loginToken", action.payload.data.token);
        });
        builder.addCase(loginUser.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Login failed";
        });
        builder.addCase(verifyOtp.pending, (state)=>{
            state.loading = true;
            state.error = null;
        });
        builder.addCase(verifyOtp.fulfilled, (state, action)=>{
            state.loading = false;
            state.isAuthenticated = true;
            state.user = action.payload.data.user;
            state.token = action.payload.data.token;
            react_secure_storage__WEBPACK_IMPORTED_MODULE_1__/* ["default"].setItem */ .Z.setItem("loginToken", action.payload.data.token);
        });
        builder.addCase(verifyOtp.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "OTP verification failed";
        });
        builder.addCase(forgotPassword.pending, (state)=>{
            state.loading = true;
            state.error = null;
        });
        builder.addCase(forgotPassword.fulfilled, (state)=>{
            state.loading = false;
        });
        builder.addCase(forgotPassword.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload || "Failed to send reset link";
        });
    }
});
const { clearError , logout  } = authSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authSlice.reducer);


/***/ }),

/***/ 95239:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RA": () => (/* binding */ fetchCommentedPosts),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "_i": () => (/* binding */ fetchAllPosts),
/* harmony export */   "fw": () => (/* binding */ clearError),
/* harmony export */   "g7": () => (/* binding */ fetchMentionedPosts),
/* harmony export */   "os": () => (/* binding */ fetchLikedPosts),
/* harmony export */   "qA": () => (/* binding */ fetchSavedPosts),
/* harmony export */   "rU": () => (/* binding */ fetchSharedPosts)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62049);
/* harmony import */ var _api_APIcall__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(26742);


const initialState = {
    posts: [],
    loading: false,
    error: null
};
// Explicitly define the return type for the thunk
const fetchSavedPosts = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createAsyncThunk */ .hg)("posts/fetchSavedPosts", async (_, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "posts/view-saved-posts",
            METHOD: "GET"
        });
        return response.data.data.posts ?? []; // Return empty array if posts is undefined
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch saved posts");
    }
});
const fetchLikedPosts = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createAsyncThunk */ .hg)("posts/fetchLikedPosts", async (_, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "posts/view-liked-posts",
            METHOD: "GET"
        });
        return response.data.data.posts ?? []; // Return empty array if posts is undefined
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch liked posts");
    }
});
const fetchSharedPosts = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createAsyncThunk */ .hg)("posts/fetchSharedPosts", async (_, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "posts/view-shared-posts",
            METHOD: "GET"
        });
        return response.data.data.posts ?? []; // Return empty array if posts is undefined
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch shared posts");
    }
});
const fetchCommentedPosts = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createAsyncThunk */ .hg)("posts/fetchCommentedPosts", async (_, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "posts/view-commented-posts",
            METHOD: "GET"
        });
        return response.data.data.posts ?? []; // Return empty array if posts is undefined
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch commented posts");
    }
});
const fetchMentionedPosts = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createAsyncThunk */ .hg)("posts/fetchMentionedPosts", async (_, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "posts/view-mentioned-posts",
            METHOD: "GET"
        });
        return response.data.data.posts ?? []; // Return empty array if posts is undefined
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch mentioned posts");
    }
});
const fetchAllPosts = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createAsyncThunk */ .hg)("posts/fetchAllPosts", async (_, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "users/profile",
            METHOD: "GET"
        });
        return response.data.data.posts ?? []; // Return empty array if posts is undefined
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch posts");
    }
});
const postSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createSlice */ .oM)({
    name: "posts",
    initialState,
    reducers: {
        clearError (state) {
            state.error = null;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchSavedPosts.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchSavedPosts.fulfilled, (state, action)=>{
            state.loading = false;
            state.posts = action.payload ? action.payload.map((post)=>({
                    ...post,
                    isSaved: true
                })) : [];
        }).addCase(fetchSavedPosts.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        }).addCase(fetchLikedPosts.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchLikedPosts.fulfilled, (state, action)=>{
            state.loading = false;
            state.posts = action.payload ? action.payload.map((post)=>({
                    ...post,
                    isLiked: true
                })) : [];
        }).addCase(fetchLikedPosts.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        }).addCase(fetchSharedPosts.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchSharedPosts.fulfilled, (state, action)=>{
            state.loading = false;
            state.posts = action.payload ? action.payload.map((post)=>({
                    ...post,
                    isShared: true
                })) : [];
        }).addCase(fetchSharedPosts.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        }).addCase(fetchCommentedPosts.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchCommentedPosts.fulfilled, (state, action)=>{
            state.loading = false;
            state.posts = action.payload ? action.payload.map((post)=>({
                    ...post,
                    isCommented: true
                })) : [];
        }).addCase(fetchCommentedPosts.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        }).addCase(fetchMentionedPosts.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchMentionedPosts.fulfilled, (state, action)=>{
            state.loading = false;
            state.posts = action.payload ? action.payload.map((post)=>({
                    ...post,
                    isMentioned: true
                })) : [];
        }).addCase(fetchMentionedPosts.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        }).addCase(fetchAllPosts.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchAllPosts.fulfilled, (state, action)=>{
            state.loading = false;
            state.posts = action.payload ?? [];
        }).addCase(fetchAllPosts.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
    }
});
const { clearError  } = postSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (postSlice.reducer);


/***/ }),

/***/ 5331:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BT": () => (/* binding */ fetchUser),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export clearError */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62049);
/* harmony import */ var _api_APIcall__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(26742);
// userSlice.ts


const initialState = {
    user: null,
    loading: false,
    error: null
};
// Thunk to fetch user profile data with expanded fields
const fetchUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createAsyncThunk */ .hg)("user/fetchUser", async (_, { rejectWithValue  })=>{
    try {
        const response = await (0,_api_APIcall__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            ENDPOINT: "users/profile?expand=totalFollowing,totalFollower,totalActivePost",
            METHOD: "GET"
        });
        return response.data.data.user;
    } catch (error) {
        return rejectWithValue(error.response?.data?.message || "Failed to fetch user profile");
    }
});
const userSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__/* .createSlice */ .oM)({
    name: "user",
    initialState,
    reducers: {
        clearError (state) {
            state.error = null;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchUser.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchUser.fulfilled, (state, action)=>{
            state.loading = false;
            state.user = action.payload;
        }).addCase(fetchUser.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
    }
});
const { clearError  } = userSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);


/***/ }),

/***/ 45596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);


/***/ }),

/***/ 7953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/add-post-avatar.48b16358.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAGFBMVEXu7u709PTMzMzY2Njm5ua5ubm4uLjS0tI6VP7mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAH0lEQVR4nGNgwAIYGRkZQTQLGxMTK5jBxMzMhCKFDgAGOAAq+vWXegAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 30954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-1.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 87041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-2.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 67048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-3.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 46387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-4.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 22354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-5.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 20474:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-6.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 21145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-7.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/hell.27a6c3fd.jpg","height":3000,"width":2400,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAYDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAfEAACAQQCAwAAAAAAAAAAAAABAgMABAURBhIiQWH/xAAVAQEBAAAAAAAAAAAAAAAAAAADBP/EABkRAAIDAQAAAAAAAAAAAAAAAAABAgMRBP/aAAwDAQACEQMRAD8Ap4LkWDiucgbvI3E0LzkwMyswK+uq68RogfdbpSlUR54YE7Hp/9k=","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 59374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.dc0c341d.png","height":34,"width":171,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAGFBMVEVeIxNtGhhRDhFmDBZpLBVXHxNCEg5JChD+K4RkAAAABXRSTlPh4N7m4C6ZB84AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAaSURBVHicY2BlY2VlZWNnZ2BgYWBgZGRiBgACngA6F4bMPAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 4756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12548);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 88944:
/***/ (() => {



/***/ }),

/***/ 7837:
/***/ (() => {



/***/ })

};
;