exports.id = 9356;
exports.ids = [9356];
exports.modules = {

/***/ 66436:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 65430))

/***/ }),

/***/ 65430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_MakePost__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(26508);
/* harmony import */ var _common_NewsFeeds__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18223);
/* harmony import */ var _menu_HomeLeft__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19461);
/* harmony import */ var _RightSide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(83738);
// components/home/HomeMain.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 





const HomeMain = ()=>{
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.usePathname)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
            className: "main-content",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container sidebar-toggler",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-xxl-3 col-xl-3 col-lg-4 col-6 cus-z2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_menu_HomeLeft__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                clss: "d-lg-none"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-xxl-6 col-xl-5 col-lg-8 mt-0 mt-lg-10 mt-xl-0 d-flex flex-column gap-7 cus-z",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_MakePost__WEBPACK_IMPORTED_MODULE_2__["default"], {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_NewsFeeds__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                    clss: "p-3 p-sm-5",
                                    reaction: pathname
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-xxl-3 col-xl-4 col-lg-4 col-6 mt-5 mt-xl-0",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RightSide__WEBPACK_IMPORTED_MODULE_5__["default"], {})
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeMain);


/***/ }),

/***/ 17347:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// components/home/HomeMain.tsx
/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/home/HomeMain.tsx");


/***/ })

};
;