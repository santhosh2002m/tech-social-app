"use strict";
exports.id = 8223;
exports.ids = [8223];
exports.modules = {

/***/ 18223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ common_NewsFeeds)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./store/hooks.tsx
var hooks = __webpack_require__(39970);
// EXTERNAL MODULE: ./store/postSlice.ts
var postSlice = __webpack_require__(95239);
// EXTERNAL MODULE: ./components/ui/ParentComment.tsx
var ParentComment = __webpack_require__(5187);
// EXTERNAL MODULE: ./components/ui/Post.tsx + 1 modules
var Post = __webpack_require__(59286);
;// CONCATENATED MODULE: ./components/ui/PostReaction.tsx
// components/ui/PostReaction.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 

const PostReaction = ({ reaction ="" , toggleCommentSection , isCommentSectionOpen , postId  })=>{
    const post = (0,hooks/* useAppSelector */.C)((state)=>state.posts.posts.find((p)=>p.id === postId));
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "like-comment-share py-5 d-center flex-wrap gap-3 gap-md-0 justify-content-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: `d-center gap-1 gap-sm-2 mdtxt ${post?.is_like ? "active" : ""}`,
                        disabled: true,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "material-symbols-outlined mat-icon",
                                children: " thumb_up "
                            }),
                            post?.total_like || 0
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: `d-center gap-1 gap-sm-2 mdtxt ${isCommentSectionOpen ? "active" : ""}`,
                        onClick: toggleCommentSection,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "material-symbols-outlined mat-icon",
                                children: " chat_bubble "
                            }),
                            post?.total_comment || 0
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: "d-center gap-1 gap-sm-2 mdtxt",
                        onClick: ()=>console.log("AI Search clicked for post:", postId),
                        title: "AI Search",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                width: "20",
                                height: "20",
                                viewBox: "0 0 48 48",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                className: "ai-search-icon",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                        cx: "20",
                                        cy: "20",
                                        r: "16",
                                        strokeWidth: "4",
                                        fill: "black",
                                        className: "ai-search-icon-stroke"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("text", {
                                        x: "13",
                                        y: "25",
                                        fontFamily: "Arial, sans-serif",
                                        fontWeight: "bold",
                                        fontSize: "14",
                                        className: "ai-search-icon-text",
                                        children: "AI"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                        x1: "31",
                                        y1: "31",
                                        x2: "44",
                                        y2: "44",
                                        strokeWidth: "4",
                                        strokeLinecap: "round",
                                        className: "ai-search-icon-stroke"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "d-none d-sm-inline",
                                children: post?.popular_point || 0
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: `d-center gap-1 gap-sm-2 mdtxt ${post?.is_share_post ? "active" : ""}`,
                        disabled: true,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                width: "20",
                                height: "20",
                                viewBox: "0 0 24 24",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                className: "share-icon",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M12 4V16M12 4L8 8M12 4L16 8M8 12H4V12H20V12H16",
                                    stroke: "currentColor",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                })
                            }),
                            post?.total_share || 0
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: "d-center gap-1 gap-sm-2 mdtxt",
                        disabled: true,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "material-symbols-outlined mat-icon",
                                children: " visibility "
                            }),
                            post?.total_view || 0
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "view-comments-date d-flex justify-content-between align-items-center mt-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "mdtxt",
                        children: [
                            "View ",
                            post?.total_comment || 0,
                            " Comments"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "mdtxt",
                        children: post?.updated_at ? new Date(post.updated_at * 1000).toLocaleDateString() : "Unknown date"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ui_PostReaction = (PostReaction);

// EXTERNAL MODULE: ./components/ui/SiblingComment.tsx
var SiblingComment = __webpack_require__(73580);
// EXTERNAL MODULE: ./components/ui/WriteComment.tsx
var WriteComment = __webpack_require__(94786);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/index.mjs + 1 modules
var dist = __webpack_require__(69964);
;// CONCATENATED MODULE: ./components/common/NewsFeeds.tsx
// components/common/NewsFeeds.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 









const NewsFeeds = ({ clss ="" , reaction =""  })=>{
    const [openCommentSections, setOpenCommentSections] = (0,react_.useState)({});
    const dispatch = (0,hooks/* useAppDispatch */.T)();
    const { posts , loading , error  } = (0,hooks/* useAppSelector */.C)((state)=>state.posts);
    (0,react_.useEffect)(()=>{
        if (error) {
            dist/* toast.error */.Am.error(error);
            dispatch((0,postSlice/* clearError */.fw)());
        }
    }, [
        error,
        dispatch
    ]);
    (0,react_.useEffect)(()=>{
        switch(reaction){
            case "/saved":
                dispatch((0,postSlice/* fetchSavedPosts */.qA)());
                break;
            case "/liked":
                dispatch((0,postSlice/* fetchLikedPosts */.os)());
                break;
            case "/shared":
                dispatch((0,postSlice/* fetchSharedPosts */.rU)());
                break;
            case "/commented":
                dispatch((0,postSlice/* fetchCommentedPosts */.RA)());
                break;
            case "/mentioned":
                dispatch((0,postSlice/* fetchMentionedPosts */.g7)());
                break;
            case "/":
            case "/posts":
                dispatch((0,postSlice/* fetchAllPosts */._i)());
                break;
            case "/chats":
            case "/explore-ai":
            case "/faq":
            case "/support":
            case "/subscription":
                break;
            default:
                dispatch((0,postSlice/* fetchAllPosts */._i)());
        }
    }, [
        reaction,
        dispatch
    ]);
    const toggleCommentSection = (postId)=>{
        setOpenCommentSections((prev)=>({
                ...prev,
                [postId]: !prev[postId] || false
            }));
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "post-item d-flex flex-column gap-5 gap-md-7",
        id: "news-feed",
        children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
            className: "text-center mdtxt",
            children: "Loading posts..."
        }) : error ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
            className: "text-center mdtxt text-danger",
            children: [
                "Error: ",
                error
            ]
        }) : posts.length === 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
            className: "text-center mdtxt",
            children: [
                "No ",
                reaction.replace("/", "") || "posts",
                " yet"
            ]
        }) : reaction === "/chats" || reaction === "/explore-ai" || reaction === "/faq" || reaction === "/support" || reaction === "/subscription" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
            className: "text-center mdtxt",
            children: [
                reaction.replace("/", "").replace("-", " ").toUpperCase(),
                " page coming soon"
            ]
        }) : posts.map((post)=>{
            const isCommentSectionOpen = openCommentSections[post.id] || false;
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `post-single-box ${clss}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Post/* default */.Z, {
                        post: post
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_PostReaction, {
                        reaction: reaction,
                        toggleCommentSection: ()=>toggleCommentSection(post.id),
                        isCommentSectionOpen: isCommentSectionOpen,
                        postId: post.id
                    }),
                    isCommentSectionOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(WriteComment/* default */.Z, {}),
                            post.comments && post.comments.map((comment)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "comments-area mt-5",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "single-comment-area ms-1 ms-xxl-15",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(ParentComment/* default */.Z, {
                                                comment: comment
                                            }),
                                            comment?.replies?.map((reply, i, arr)=>/*#__PURE__*/ jsx_runtime_.jsx(SiblingComment/* default */.Z, {
                                                    clss: arr.length - 1 === i ? "single-comment-area" : "sibling-comment",
                                                    reply: reply
                                                }, reply.id))
                                        ]
                                    })
                                }, comment.id))
                        ]
                    })
                ]
            }, post.id);
        })
    });
};
/* harmony default export */ const common_NewsFeeds = (NewsFeeds);


/***/ })

};
;