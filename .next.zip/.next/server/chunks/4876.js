exports.id = 4876;
exports.ids = [4876];
exports.modules = {

/***/ 96683:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// components/common/NewsFeeds.tsx
/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/NewsFeeds.tsx");


/***/ }),

/***/ 6447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const bioData = [
    {
        id: 1,
        type: "Developer",
        icon: "integration_instructions",
        class: ""
    },
    {
        id: 2,
        type: "Master's degree",
        icon: "school",
        class: ""
    },
    {
        id: 3,
        type: "test@mail.com",
        icon: "flag",
        class: "link"
    },
    {
        id: 4,
        type: "www.wisoky.com",
        icon: "language",
        class: "link"
    },
    {
        id: 5,
        type: "(316) 555-0116",
        icon: "call",
        class: ""
    },
    {
        id: 6,
        type: "USA",
        icon: "pin_drop",
        class: ""
    },
    {
        id: 7,
        type: "775 Rolling Green Rd.",
        icon: "house",
        class: ""
    }
];
const About = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-inline-block d-lg-none",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                    className: "button profile-active mb-4 mb-lg-0 d-flex align-items-center gap-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-symbols-outlined mat-icon",
                            children: " tune "
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "My profile"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "profile-sidebar cus-scrollbar max-width p-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "d-block d-lg-none position-absolute end-0 top-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "button profile-close",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "material-symbols-outlined mat-icon fs-xl",
                                children: "close"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "sidebar-area",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "d-inline-flex",
                                    children: "About"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mdtxt descript",
                                children: "Lorem ipsum dolor sit amet cons all Ofectetur. Pellentesque ipsum necat congue pretium cursus orci. It Commodo donec tellus lacus pellentesque sagittis habitant quam amet praesent."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "sidebar-area mt-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-2",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    className: "d-inline-flex",
                                    children: "Info"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "d-grid gap-2 mt-4",
                                children: bioData.map((itm)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "d-flex align-items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                className: "material-symbols-outlined mat-icon",
                                                children: itm.icon
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: `mdtxt ${itm.class}`,
                                                children: itm.type
                                            })
                                        ]
                                    }, itm.id))
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);


/***/ }),

/***/ 41343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ marketplacePost_Photos)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(62208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/images/post-img-14.png
/* harmony default export */ const post_img_14 = ({"src":"/_next/static/media/post-img-14.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/post-img-15.png
/* harmony default export */ const post_img_15 = ({"src":"/_next/static/media/post-img-15.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/post-img-16.png
/* harmony default export */ const post_img_16 = ({"src":"/_next/static/media/post-img-16.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/post-img-17.png
/* harmony default export */ const post_img_17 = ({"src":"/_next/static/media/post-img-17.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/post-img-5.png
/* harmony default export */ const post_img_5 = ({"src":"/_next/static/media/post-img-5.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/post-img-6.png
/* harmony default export */ const post_img_6 = ({"src":"/_next/static/media/post-img-6.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/marketplacePost/Photos.tsx








const Photos = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mb-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                    className: "d-inline-flex",
                    children: "Photos"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "post-single-box",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "post-img d-flex justify-content-between flex-wrap gap-2 gap-lg-3",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "single d-grid gap-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: post_img_6,
                                    alt: "image"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: post_img_14,
                                    alt: "image"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "single d-grid gap-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: post_img_5,
                                    alt: "image"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: post_img_15,
                                    alt: "image"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "single d-flex gap-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: post_img_16,
                                    alt: "image"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: post_img_17,
                                    alt: "image"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const marketplacePost_Photos = (Photos);


/***/ }),

/***/ 63881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/node_modules/next/dist/client/image.js");
 //# sourceMappingURL=image.js.map


/***/ }),

/***/ 62208:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(63881);


/***/ }),

/***/ 13781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/post-img-14.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 17425:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/post-img-15.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 93101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/post-img-16.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 4681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/post-img-17.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 47431:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/post-img-5.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/post-img-6.05c266ac.png","height":132,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAD1BMVEXu7u7y8vLR0dHf39/Ly8u46dY4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJElEQVR4nGNgwAIYGRkYwQwWJmYWZhCTiYmZiRkixcgIkUMFAAViACbFh2p7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ })

};
;