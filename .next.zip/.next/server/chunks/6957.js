"use strict";
exports.id = 6957;
exports.ids = [6957];
exports.modules = {

/***/ 63881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/node_modules/next/dist/client/image.js");
 //# sourceMappingURL=image.js.map


/***/ }),

/***/ 62208:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


module.exports = __webpack_require__(63881);


/***/ }),

/***/ 49302:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/profile-picture.7887a95e.png","height":140,"width":140,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u7z8/PQ0NDb29vExMTn5+cSdtQvAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAIUlEQVR4nGNgwAIYQYCBgYGViYmZiRnEYGFiZmFClkIHAAbdADDWyL5rAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 84331:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/profile-picture.7887a95e.png","height":140,"width":140,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u7z8/PQ0NDb29vExMTn5+cSdtQvAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAIUlEQVR4nGNgwAIYQYCBgYGViYmZiRnEYGFiZmFClkIHAAbdADDWyL5rAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ })

};
;