"use strict";
exports.id = 6508;
exports.ids = [6508];
exports.modules = {

/***/ 26508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/emoji-picker-react/dist/index.js
var dist = __webpack_require__(10480);
// EXTERNAL MODULE: ./node_modules/react-calendar/dist/Calendar.css
var Calendar = __webpack_require__(84448);
;// CONCATENATED MODULE: ./components/ui/CreatePoll.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 

// import Calendar, { Value } from "react-calendar";

const CreatePoll = ({ onCancel , onSubmitPoll  })=>{
    const [pollQuestion, setPollQuestion] = (0,react_.useState)("");
    const [pollOptions, setPollOptions] = (0,react_.useState)([
        "",
        ""
    ]);
    const [hideVotes, setHideVotes] = (0,react_.useState)(false);
    const [anonymousVotes, setAnonymousVotes] = (0,react_.useState)(false);
    const [pollDuration, setPollDuration] = (0,react_.useState)(null);
    const [tempDate, setTempDate] = (0,react_.useState)(null);
    const [showCalendar, setShowCalendar] = (0,react_.useState)(false);
    const [submittedPoll, setSubmittedPoll] = (0,react_.useState)(null);
    const addPollOption = ()=>{
        if (pollOptions.length < 5) {
            setPollOptions([
                ...pollOptions,
                ""
            ]);
        }
    };
    const handleOptionChange = (index, value)=>{
        const updatedOptions = [
            ...pollOptions
        ];
        updatedOptions[index] = value;
        setPollOptions(updatedOptions);
    };
    const handleStartPoll = ()=>{
        const pollData = {
            question: pollQuestion,
            options: pollOptions.filter((option)=>option.trim() !== ""),
            hideVotes,
            anonymousVotes,
            duration: pollDuration ? pollDuration.toISOString() : ""
        };
        setSubmittedPoll(pollData);
        onSubmitPoll(pollData);
        setPollQuestion("");
        setPollOptions([
            "",
            ""
        ]);
        setHideVotes(false);
        setAnonymousVotes(false);
        setPollDuration(null);
        setTempDate(null);
        setShowCalendar(false);
    };
    const handleCancelPoll = ()=>{
        setPollQuestion("");
        setPollOptions([
            "",
            ""
        ]);
        setHideVotes(false);
        setAnonymousVotes(false);
        setPollDuration(null);
        setTempDate(null);
        setShowCalendar(false);
        setSubmittedPoll(null);
        onCancel();
    };
    const handleHideVotesChange = (e)=>{
        setHideVotes(e.target.checked);
        console.log("Hide Votes:", e.target.checked);
    };
    const handleAnonymousVotesChange = (e)=>{
        setAnonymousVotes(e.target.checked);
        console.log("Anonymous Votes:", e.target.checked);
    };
    const handleCalendarOk = ()=>{
        setPollDuration(tempDate);
        setShowCalendar(false);
    };
    const handleCalendarCancel = ()=>{
        setTempDate(null);
        setShowCalendar(false);
    };
    const toggleCalendar = ()=>{
        setShowCalendar(!showCalendar);
    };
    // Handle calendar change with correct type and event parameter
    // const handleCalendarChange = (
    //   value: Value,
    //   event: React.MouseEvent<HTMLButtonElement, MouseEvent>
    // ): void => {
    //   if (value instanceof Date) {
    //     setTempDate(value);
    //   } else if (Array.isArray(value) && value[0] instanceof Date) {
    //     setTempDate(value[0]); // Use first date if range is provided (though selectRange={false})
    //   } else {
    //     setTempDate(null);
    //   }
    // };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "poll-creation w-100",
        children: [
            submittedPoll && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "submitted-poll mb-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        children: submittedPoll.question
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        children: submittedPoll.options.map((option, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-2 d-flex align-items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "radio",
                                        name: "poll-option",
                                        id: `option-${index}`,
                                        disabled: true
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: `option-${index}`,
                                        className: "ms-2",
                                        children: option
                                    })
                                ]
                            }, index))
                    }),
                    submittedPoll.duration && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Ends on: ",
                            new Date(submittedPoll.duration).toLocaleDateString()
                        ]
                    }),
                    submittedPoll.hideVotes && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Votes hidden until poll ends"
                    }),
                    submittedPoll.anonymousVotes && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Anonymous voting enabled"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "single-input",
                children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                    cols: 10,
                    rows: 2,
                    placeholder: "What's up?",
                    value: pollQuestion,
                    onChange: (e)=>setPollQuestion(e.target.value),
                    className: "w-100"
                })
            }),
            pollOptions.map((option, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "single-input",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        placeholder: "Option",
                        value: option,
                        onChange: (e)=>handleOptionChange(index, e.target.value)
                    })
                }, index)),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                className: "d-flex align-items-center gap-2 mb-3",
                onClick: addPollOption,
                disabled: pollOptions.length >= 5,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "material-symbols-outlined",
                        children: "add"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Add more options"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "single-input mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "calendar-btn",
                        onClick: toggleCalendar,
                        type: "button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "material-symbols-outlined",
                            children: "calendar_today"
                        })
                    }),
                    showCalendar && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "calendar-wrapper",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "poll-calendar-buttons",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: handleCalendarCancel,
                                    children: "Cancel"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: handleCalendarOk,
                                    children: "OK"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "checkbox-single",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    htmlFor: "hide-votes",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "checkbox",
                            id: "hide-votes",
                            checked: hideVotes,
                            onChange: handleHideVotesChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "checkmark"
                        }),
                        "Hide votes until poll ends"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "checkbox-single",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    htmlFor: "anonymous-votes",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "checkbox",
                            id: "anonymous-votes",
                            checked: anonymousVotes,
                            onChange: handleAnonymousVotesChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "checkmark"
                        }),
                        "Anonymous votes"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "d-flex align-items-center gap-3 mt-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "d-flex justify-content-between align-items-center w-100 end",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "d-flex gap-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "text-white",
                                onClick: handleCancelPoll,
                                children: "CANCEL"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "cmn-btn",
                                onClick: handleStartPoll,
                                children: "Start Poll"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const ui_CreatePoll = (CreatePoll);

// EXTERNAL MODULE: ./public/images/hell.jpg
var hell = __webpack_require__(6670);
;// CONCATENATED MODULE: ./components/ui/CreatePost.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 






const CreatePost = ()=>{
    const [isPollMode, setIsPollMode] = (0,react_.useState)(false);
    const [selectedDocuments, setSelectedDocuments] = (0,react_.useState)([]);
    const [selectedMedia, setSelectedMedia] = (0,react_.useState)([]);
    const [showEmojiPicker, setShowEmojiPicker] = (0,react_.useState)(false);
    const [postContent, setPostContent] = (0,react_.useState)("");
    const documentInputRef = (0,react_.useRef)(null);
    const mediaInputRef = (0,react_.useRef)(null);
    const emojiPickerRef = (0,react_.useRef)(null);
    const emojiIconRef = (0,react_.useRef)(null);
    const handleDocumentChange = (e)=>{
        const files = e.target.files ? Array.from(e.target.files) : [];
        setSelectedDocuments(files);
    };
    const handleMediaChange = (e)=>{
        const files = e.target.files ? Array.from(e.target.files) : [];
        setSelectedMedia(files);
    };
    const triggerDocumentInput = ()=>{
        documentInputRef.current?.click();
    };
    const triggerMediaInput = ()=>{
        mediaInputRef.current?.click();
    };
    const removeDocument = (index)=>{
        setSelectedDocuments(selectedDocuments.filter((_, i)=>i !== index));
    };
    const removeMedia = (index)=>{
        setSelectedMedia(selectedMedia.filter((_, i)=>i !== index));
    };
    const toggleEmojiPicker = ()=>{
        setShowEmojiPicker(!showEmojiPicker);
    };
    const handleEmojiClick = (emojiData)=>{
        setPostContent((prev)=>prev + emojiData.emoji);
        setShowEmojiPicker(false);
    };
    const handlePostSubmit = (e)=>{
        e.preventDefault();
        if (!postContent.trim() && selectedMedia.length === 0 && selectedDocuments.length === 0) {
            alert("Please add some content to post!");
            return;
        }
        const postData = {
            content: postContent,
            media: selectedMedia,
            documents: selectedDocuments,
            timestamp: new Date().toISOString()
        };
        console.log("Submitted Post:", postData);
        setPostContent("");
        setSelectedMedia([]);
        setSelectedDocuments([]);
    };
    (0,react_.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (emojiPickerRef.current && !emojiPickerRef.current.contains(event.target) && emojiIconRef.current && !emojiIconRef.current.contains(event.target)) {
                setShowEmojiPicker(false);
            }
        };
        if (showEmojiPicker) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        showEmojiPicker
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "share-post d-flex gap-2 gap-sm-3 p-2 p-sm-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "profile-box",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: hell/* default */.Z,
                        width: 40,
                        height: 40,
                        className: "max-un",
                        alt: "profile avatar"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-100 position-relative",
                children: !isPollMode ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    onSubmit: handlePostSubmit,
                    className: "w-100 position-relative",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            cols: 10,
                            rows: 2,
                            placeholder: "Write something to Lerio...",
                            className: "w-100",
                            value: postContent,
                            onChange: (e)=>setPostContent(e.target.value)
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "abs-area position-absolute d-none d-sm-block",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon xxltxt",
                                    onClick: toggleEmojiPicker,
                                    ref: emojiIconRef,
                                    children: "sentiment_satisfied"
                                }),
                                showEmojiPicker && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "emoji-picker",
                                    ref: emojiPickerRef,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(dist["default"], {
                                        onEmojiClick: handleEmojiClick
                                    })
                                })
                            ]
                        }),
                        selectedMedia.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "selected-media mt-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    children: "Selected Photos/Videos:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    children: selectedMedia.map((file, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            className: "smtxt d-flex align-items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: file.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "cmn-btn alt smtxt",
                                                    onClick: ()=>removeMedia(index),
                                                    children: "Remove"
                                                })
                                            ]
                                        }, index))
                                })
                            ]
                        }),
                        selectedDocuments.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "selected-documents mt-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    children: "Selected Documents:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    children: selectedDocuments.map((file, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            className: "smtxt d-flex align-items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: file.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "cmn-btn alt smtxt",
                                                    onClick: ()=>removeDocument(index),
                                                    children: "Remove"
                                                })
                                            ]
                                        }, index))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "d-flex align-items-center mt-2 gap-2 action-list space-between",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "d-flex align-items-center gap-2",
                                    onClick: triggerMediaInput,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "material-symbols-outlined icon-orange lgtxt",
                                            children: "photo"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Photo/Video"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "file",
                                            ref: mediaInputRef,
                                            multiple: true,
                                            accept: "image/*,video/*",
                                            style: {
                                                display: "none"
                                            },
                                            onChange: handleMediaChange
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "d-flex align-items-center gap-2 choose-documents",
                                    onClick: triggerDocumentInput,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "material-symbols-outlined icon-orange lgtxt",
                                            children: "description"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Choose Documents"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "file",
                                            ref: documentInputRef,
                                            multiple: true,
                                            accept: ".pdf,.doc,.docx,.txt",
                                            style: {
                                                display: "none"
                                            },
                                            onChange: handleDocumentChange
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "d-flex align-items-center gap-2",
                                    onClick: ()=>setIsPollMode(true),
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "material-symbols-outlined",
                                            children: "poll"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Poll"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "d-flex align-items-center gap-2",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        type: "submit",
                                        className: "cmn-btn custom-post-btn",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "material-symbols-outlined",
                                                children: "send"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Post"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx(ui_CreatePoll, {
                    onCancel: ()=>setIsPollMode(false),
                    onSubmitPoll: (pollData)=>console.log("Submitted Poll:", pollData)
                })
            })
        ]
    });
};
/* harmony default export */ const ui_CreatePost = (CreatePost);

;// CONCATENATED MODULE: ./components/common/MakePost.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

function Home() {
    return /*#__PURE__*/ jsx_runtime_.jsx(ui_CreatePost, {});
}


/***/ })

};
;