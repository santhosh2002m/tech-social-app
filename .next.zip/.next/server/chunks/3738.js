"use strict";
exports.id = 3738;
exports.ids = [3738];
exports.modules = {

/***/ 83738:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_Contact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74692);
/* __next_internal_client_entry_do_not_use__  auto */ 


const RightSide = ()=>{
    const [activeProfile, setActiveProfile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [activeAccordion, setActiveAccordion] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("followings");
    const toggleAccordion = (section)=>{
        console.log("Toggling accordion:", section, "Current state:", activeAccordion);
        setActiveAccordion(activeAccordion === section ? "" : section);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `cus-overflow cus-scrollbar sidebar-head ${activeProfile ? "active" : ""}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-flex justify-content-end",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "d-block d-xl-none me-4",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "button toggler-btn mb-4 mb-lg-0 d-flex align-items-center gap-2",
                        onClick: ()=>{
                            console.log("Toggling sidebar:", !activeProfile);
                            setActiveProfile(!activeProfile);
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "My List"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "material-symbols-outlined mat-icon",
                                children: "tune"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "cus-scrollbar side-wrapper",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sidebar-wrapper d-flex flex-column gap-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "sidebar-area p-5",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "accordion",
                            id: "sidebarAccordion",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "accordion-item accordion-item-custom",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "accordion-header",
                                            id: "followersHeading",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: `accordion-button accordion-button-custom ${activeAccordion !== "followers" ? "collapsed" : ""}`,
                                                type: "button",
                                                onClick: ()=>toggleAccordion("followers"),
                                                "aria-expanded": activeAccordion === "followers",
                                                "aria-controls": "followersCollapse",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                    className: "m-0",
                                                    children: "Followers"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            id: "followersCollapse",
                                            className: `accordion-collapse collapse ${activeAccordion === "followers" ? "show" : ""}`,
                                            "aria-labelledby": "followersHeading",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "accordion-body",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Contact__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                                    sectionType: "followers",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mb-4"
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "accordion-item accordion-item-custom mt-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "accordion-header",
                                            id: "followingsHeading",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: `accordion-button accordion-button-custom ${activeAccordion !== "followings" ? "collapsed" : ""}`,
                                                type: "button",
                                                onClick: ()=>toggleAccordion("followings"),
                                                "aria-expanded": activeAccordion === "followings",
                                                "aria-controls": "followingsCollapse",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                    className: "m-0",
                                                    children: "Followings"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            id: "followingsCollapse",
                                            className: `accordion-collapse collapse ${activeAccordion === "followings" ? "show" : ""}`,
                                            "aria-labelledby": "followingsHeading",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "accordion-body",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Contact__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                                    sectionType: "followings",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mb-4"
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RightSide);


/***/ })

};
;