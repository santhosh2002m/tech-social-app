exports.id = 2153;
exports.ids = [2153];
exports.modules = {

/***/ 75784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(69535);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__  auto */ 

const ApexCharts = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(null, {
    loadableGenerated: {
        modules: [
            "/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/charts/BarChart.tsx -> " + "react-apexcharts"
        ]
    },
    ssr: false
});
const BarChart = ({ color ="#7579FF" , options  })=>{
    // charts series
    const series = [
        {
            show: true,
            data: [
                30,
                50,
                40,
                50,
                70,
                65,
                90
            ]
        }
    ];
    // charts options
    const defaultOptions = {
        chart: {
            height: 250,
            type: "bar",
            toolbar: {
                show: false
            }
        },
        tooltip: {
            enabled: false
        },
        colors: [
            color
        ],
        plotOptions: {
            bar: {
                columnWidth: "20%",
                distributed: false
            }
        },
        dataLabels: {
            enabled: false
        },
        legend: {
            show: false
        },
        xaxis: {
            categories: [
                [
                    "Nov 23"
                ],
                [
                    "Nov 24"
                ],
                [
                    "Nov 25"
                ],
                [
                    "Nov 26"
                ],
                [
                    "Nov 27"
                ],
                [
                    "Nov 28"
                ],
                [
                    "Nov 29"
                ],
                [
                    "Nov 30"
                ],
                [
                    "Dec 1"
                ]
            ],
            labels: {
                style: {
                    colors: "var(--para-1st-color)"
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: "var(--para-1st-color)"
                }
            }
        }
    };
    const chartOptions = options ?? defaultOptions;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ApexCharts, {
        type: "bar",
        series: series,
        options: chartOptions,
        height: 250
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BarChart);


/***/ }),

/***/ 34884:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/charts/BarChart.tsx");


/***/ }),

/***/ 38127:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/select/Select.tsx");


/***/ })

};
;