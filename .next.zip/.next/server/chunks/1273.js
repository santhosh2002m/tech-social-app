exports.id = 1273;
exports.ids = [1273];
exports.modules = {

/***/ 69640:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 15567))

/***/ }),

/***/ 15567:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_menu_GroupLeftMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84500);
/* harmony import */ var _data_sidbarData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76922);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_images_avatar_13_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34390);
/* __next_internal_client_entry_do_not_use__  auto */ 




const PagesLayout = ({ params , children  })=>{
    const { getLayout  } = params;
    const { pageId  } = (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.useParams)();
    if (getLayout || pageId) {
        return children;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        className: "main-content",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-xl-3 col-lg-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_menu_GroupLeftMenu__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            adminTools: _data_sidbarData__WEBPACK_IMPORTED_MODULE_4__/* .pageAdminTools */ .Tc,
                            img: _public_images_avatar_13_png__WEBPACK_IMPORTED_MODULE_3__["default"],
                            name: "Java World",
                            type: "Public"
                        })
                    }),
                    children
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PagesLayout);


/***/ }),

/***/ 99619:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/(pages)/layout.tsx");


/***/ }),

/***/ 34390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-13.48b16358.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAGFBMVEXu7u709PTMzMzY2Njm5ua5ubm4uLjS0tI6VP7mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAH0lEQVR4nGNgwAIYGRkZQTQLGxMTK5jBxMzMhCKFDgAGOAAq+vWXegAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ })

};
;