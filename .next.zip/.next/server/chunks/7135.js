"use strict";
exports.id = 7135;
exports.ids = [7135];
exports.modules = {

/***/ 37135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ProfileBanner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38022);
/* harmony import */ var _ProfileBanner__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ProfileBanner__WEBPACK_IMPORTED_MODULE_1__);


const PublicProfileMain = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        className: "main-content",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ProfileBanner__WEBPACK_IMPORTED_MODULE_1___default()), {
                            tabData: [
                                [
                                    "Post",
                                    "post",
                                    "/public-profile/post"
                                ],
                                [
                                    "About",
                                    "about",
                                    "/public-profile/about"
                                ],
                                [
                                    "Photos",
                                    "photos",
                                    "/public-profile/photos"
                                ],
                                [
                                    "Groups",
                                    "group",
                                    "/public-profile/group"
                                ],
                                [
                                    "Connections",
                                    "connections",
                                    "/public-profile/connections"
                                ],
                                [
                                    "Events",
                                    "events",
                                    "/public-profile/events"
                                ]
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row sidebar-toggler",
                    children: children
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PublicProfileMain);


/***/ })

};
;