exports.id = 6139;
exports.ids = [6139];
exports.modules = {

/***/ 7064:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46529));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 74692));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 40408, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61324));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22717));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67858));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60942));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57737));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 87538));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 41478));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67640));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 47940));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95945));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23002));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60450))

/***/ }),

/***/ 63881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/node_modules/next/dist/client/image.js");
 //# sourceMappingURL=image.js.map


/***/ }),

/***/ 62208:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(63881);


/***/ })

};
;