exports.id = 6728;
exports.ids = [6728];
exports.modules = {

/***/ 15563:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1560);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ui_ContactAction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(33529);
/* harmony import */ var _public_images_hell_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6670);
/* harmony import */ var _store_userSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5331);
/* harmony import */ var react_secure_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65673);
/* __next_internal_client_entry_do_not_use__  auto */ 









const ProfileEditBanner = ()=>{
    const path = (0,next_navigation__WEBPACK_IMPORTED_MODULE_4__.usePathname)();
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const { user , loading , error  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.user);
    const lastPath = path.split("/").pop() || "";
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const token = react_secure_storage__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getItem */ .Z.getItem("loginToken");
        if (!token) {
            router.push("/login");
            return;
        }
        dispatch((0,_store_userSlice__WEBPACK_IMPORTED_MODULE_8__/* .fetchUser */ .BT)());
    }, [
        dispatch,
        router
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (error === "Session expired. Please log in again.") {
            router.push("/login");
        }
    }, [
        error,
        router
    ]);
    // Generate bioData dynamically based on API response
    const bioData = user ? [
        user.industry && {
            id: 1,
            type: user.industry,
            label: "Industry",
            icon: "factory",
            class: ""
        },
        user.location && {
            id: 2,
            type: user.location,
            label: "Location",
            icon: "pin_drop",
            class: ""
        },
        user.website && {
            id: 3,
            type: user.website,
            label: "Website",
            icon: "link",
            class: "link"
        },
        user.email && {
            id: 4,
            type: user.email,
            label: "Email",
            icon: "email",
            class: ""
        },
        user.phone && {
            id: 5,
            type: `${user.country_code} ${user.phone}`,
            label: "Phone",
            icon: "call",
            class: ""
        },
        user.profileCategoryName && {
            id: 6,
            type: user.profileCategoryName,
            label: "Category",
            icon: "category",
            class: ""
        }
    ].filter(Boolean) // Remove falsy entries
     : [];
    // Generate statsData dynamically based on API response
    const statsData = user ? [
        {
            id: 1,
            icon: "description",
            label: `${user.totalActivePost || 0} post`
        },
        {
            id: 2,
            icon: "visibility",
            label: `${user.profile_views || 0} Views`
        },
        {
            id: 3,
            icon: "group",
            label: `${user.totalFollower || 0} followers`
        },
        {
            id: 4,
            icon: "person_add",
            label: `${user.totalFollowing || 0} following`
        }
    ] : [];
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "text-center mt-5",
            children: "Loading..."
        });
    }
    if (error) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "text-center text-danger mt-5",
            children: error
        });
    }
    if (!user) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "text-center mt-5",
            children: "No profile data available."
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "banner-area pages-create mb-5",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "single-box p-5",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "avatar-area",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "banner-text",
                        children: "TechSocial"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "top-area",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "avatar-item position-relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    className: "avatar-img max-un setting-size-120",
                                    src: user.image || _public_images_hell_jpg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                    alt: "avatar",
                                    width: 120,
                                    height: 120
                                }),
                                user.is_verified === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "badge bg-primary text-white position-absolute bottom-0 end-0 rounded-circle p-1",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-symbols-outlined",
                                        children: "verified"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-area",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "btn-section",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/profile/edit",
                                            className: "cmn-btn d-center gap-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "material-symbols-outlined mat-icon",
                                                    children: "edit_note"
                                                }),
                                                "Edit Profile"
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_ContactAction__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            sectionType: "followings",
                                            actionList: [
                                                [
                                                    "Block",
                                                    "lock"
                                                ],
                                                [
                                                    "Report",
                                                    "flag"
                                                ]
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "content-sections",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "user-info-section",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "d-flex align-items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                            className: "m-0 xltxt",
                                                            children: user.name || "Unknown User"
                                                        }),
                                                        user.is_verified === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "material-symbols-outlined text-primary",
                                                            children: "verified"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: "m-0 text-orange-500 lgtxt margin-bottom",
                                                    children: [
                                                        "@",
                                                        user.username
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "about-text mb-0 lgtxt",
                                                    children: user.bio || "No bio available"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "bio-data-section",
                                            children: bioData.map((itm)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "d-flex align-items-center gap-2 mb-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "mdtxt d-center",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                className: "material-symbols-outlined lgtxt",
                                                                children: itm.icon
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: `info-content lgtxt ${itm.class}`,
                                                            children: itm.type
                                                        })
                                                    ]
                                                }, itm.id))
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "stats-section",
                                            children: statsData.map((stat)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "d-flex align-items-center gap-2 mb-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "mdtxt d-center",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                className: "material-symbols-outlined lgtxt",
                                                                children: stat.icon
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "profile-icon-content lgtxt",
                                                            children: stat.label
                                                        })
                                                    ]
                                                }, stat.id))
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "empty-section"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "page-details",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "nav mt-5 pt-4 flex-wrap gap-2 tab-area",
                        children: [
                            {
                                id: "posts",
                                label: "Posts"
                            },
                            {
                                id: "likes",
                                label: "Likes"
                            },
                            {
                                id: "share",
                                label: "Shares"
                            },
                            {
                                id: "comments",
                                label: "Comments"
                            },
                            {
                                id: "mentions",
                                label: "Mentions"
                            },
                            {
                                id: "saved",
                                label: "Saved"
                            }
                        ].map((tab)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "nav-item",
                                role: "presentation",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: `/profile/${tab.id}`,
                                    className: `nav-link d-center lgtxt ${lastPath === tab.id ? "active" : ""}`,
                                    children: tab.label
                                })
                            }, tab.id))
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProfileEditBanner);


/***/ }),

/***/ 95342:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/ProfileEditBanner.tsx");


/***/ }),

/***/ 37315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ProfileEditBanner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95342);
/* harmony import */ var _ProfileEditBanner__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ProfileEditBanner__WEBPACK_IMPORTED_MODULE_1__);


const ProfileMain = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        className: "main-content",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ProfileEditBanner__WEBPACK_IMPORTED_MODULE_1___default()), {})
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row sidebar-toggler",
                    children: children
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProfileMain);


/***/ })

};
;