"use strict";
exports.id = 9446;
exports.ids = [9446];
exports.modules = {

/***/ 59446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ProfileBanner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38022);
/* harmony import */ var _ProfileBanner__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ProfileBanner__WEBPACK_IMPORTED_MODULE_1__);


const MarketplacePostMain = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        className: "main-content",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "banner-area pages-create mb-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ProfileBanner__WEBPACK_IMPORTED_MODULE_1___default()), {
                                tabData: [
                                    [
                                        "Post",
                                        "post",
                                        "/marketplace/post"
                                    ],
                                    [
                                        "About",
                                        "about",
                                        "/marketplace/about"
                                    ],
                                    [
                                        "Photos",
                                        "photos",
                                        "/marketplace/photos"
                                    ],
                                    [
                                        "Groups",
                                        "group",
                                        "/marketplace/group"
                                    ],
                                    [
                                        "Connections",
                                        "connections",
                                        "/marketplace/connections"
                                    ],
                                    [
                                        "Events",
                                        "events",
                                        "/marketplace/events"
                                    ],
                                    [
                                        "Marketplace",
                                        "market",
                                        "/marketplace/market"
                                    ]
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row sidebar-toggler",
                    children: children
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MarketplacePostMain);


/***/ })

};
;