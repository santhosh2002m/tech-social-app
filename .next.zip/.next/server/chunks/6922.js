"use strict";
exports.id = 6922;
exports.ids = [6922];
exports.modules = {

/***/ 76922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Sk": () => (/* binding */ homeLeftMenu),
/* harmony export */   "Tc": () => (/* binding */ pageAdminTools),
/* harmony export */   "qJ": () => (/* binding */ friendLeftMenu)
/* harmony export */ });
/* unused harmony export adminTools */
const pageAdminTools = [
    [
        "account_circle",
        "Dashboard",
        "/pages-dashboard"
    ],
    [
        "group",
        "Your Pages",
        "/pages-your"
    ],
    [
        "bookmark_add",
        "Privacy",
        "/pages-privacy"
    ],
    [
        "settings",
        "Settings",
        "/pages-setting"
    ]
];
const adminTools = (/* unused pure expression or super */ null && ([
    [
        "account_circle",
        "Admin Assist",
        "/group-admin-assist"
    ],
    [
        "group",
        "Member request",
        "/group-member-request"
    ],
    [
        "checklist",
        "Post approvals",
        "/group-posts"
    ],
    [
        "workspace_premium",
        "Event",
        "/group-event"
    ],
    [
        "workspaces",
        "Group activity",
        "/group-activity"
    ],
    [
        "bookmark_add",
        "Privacy",
        "/group-privacy"
    ],
    [
        "settings",
        "Settings",
        "/group-setting"
    ]
]));
const friendLeftMenu = [
    [
        "person",
        "Friend Request",
        "/friend-request"
    ],
    [
        "person_add",
        "Suggestions",
        "/suggestions"
    ],
    [
        "person",
        "All Friend",
        "/all-friend"
    ],
    [
        "lock",
        "Block List",
        "/block-list"
    ]
];
// data/sidbarData.ts
// data/sidbarData.ts
const homeLeftMenu = [
    [
        "home",
        "Home",
        "/"
    ],
    [
        "chat",
        "Chats",
        "/chats"
    ],
    [
        "add",
        "Post",
        "/posts"
    ],
    [
        "travel_explore",
        "Explore AI",
        "/explore-ai"
    ],
    [
        "thumb_up_alt",
        "Liked",
        "/liked"
    ],
    [
        "reply",
        "Shared ",
        "/shared"
    ],
    [
        "mode_comment",
        "Commented ",
        "/commented"
    ],
    [
        "alternate_email",
        "Mentioned ",
        "/mentioned"
    ],
    [
        "turned_in",
        "Saved ",
        "/saved"
    ],
    [
        "quiz",
        "FAQ",
        "/faq"
    ],
    [
        "support_agent",
        "Support",
        "/support"
    ],
    [
        "subscriptions",
        "Subscriptions",
        "/subscription"
    ]
];


/***/ })

};
;