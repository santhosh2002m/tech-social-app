exports.id = 8287;
exports.ids = [8287];
exports.modules = {

/***/ 51936:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_modal_video__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16438);
/* harmony import */ var _common_Vedios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3272);
/* harmony import */ var _About__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(66594);
/* __next_internal_client_entry_do_not_use__  auto */ 




const VideosTab = ()=>{
    const [isOpen, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_modal_video__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                channel: "youtube",
                isOpen: isOpen,
                videoId: "muczNvx9fgg",
                onClose: ()=>setOpen(false)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Vedios__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                setOpen: setOpen
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-xxl-4 col-lg-10 mt-5 mt-xl-0",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_About__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VideosTab);


/***/ }),

/***/ 47762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_GroupDetailsMiddle)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/common/BioContent.tsx
var BioContent = __webpack_require__(7023);
;// CONCATENATED MODULE: ./components/groupDetails/About.tsx

const About = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "cus-scrollbar",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "sidebar-wrapper d-flex al-item flex-wrap justify-content-end justify-content-xl-center flex-column flex-md-row flex-xl-column flex gap-6",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sidebar-area p-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mb-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            className: "d-inline-flex",
                            children: "About"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "mdtxt descript",
                        children: "Lorem ipsum dolor sit amet cons all Ofectetur. Pellentesque ipsum necat congue pretium cursus orci. It Commodo donec tellus lacus pellentesque sagittis habitant quam amet praesent."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "d-grid gap-2 mt-5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "schedule"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mdtxt",
                                        children: "Always"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "flag"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mdtxt",
                                        children: "31k Member"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "language"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mdtxt",
                                        children: "Public"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const groupDetails_About = (About);

;// CONCATENATED MODULE: ./components/groupDetails/AboutTab.tsx



const AboutTab = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-xxl-8 col-xl-7",
                children: /*#__PURE__*/ jsx_runtime_.jsx(BioContent/* default */.Z, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-xxl-4 col-xl-5 col-lg-10 mt-5 mt-xl-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_About, {})
            })
        ]
    });
};
/* harmony default export */ const groupDetails_AboutTab = (AboutTab);

// EXTERNAL MODULE: ./components/common/Connections.tsx + 18 modules
var Connections = __webpack_require__(5763);
;// CONCATENATED MODULE: ./components/groupDetails/ConnectionsTab.tsx



const ConnectionsTab = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Connections/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-xxl-4 col-lg-10 mt-5 mt-xl-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_About, {})
            })
        ]
    });
};
/* harmony default export */ const groupDetails_ConnectionsTab = (ConnectionsTab);

// EXTERNAL MODULE: ./components/common/MakePost.tsx
var MakePost = __webpack_require__(17893);
// EXTERNAL MODULE: ./components/common/NewsFeeds.tsx
var NewsFeeds = __webpack_require__(96683);
var NewsFeeds_default = /*#__PURE__*/__webpack_require__.n(NewsFeeds);
;// CONCATENATED MODULE: ./components/groupDetails/FeedTab.tsx




const FeedTab = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-xxl-8 col-xl-8 col-lg-12 d-flex flex-column gap-7",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(MakePost/* default */.ZP, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((NewsFeeds_default()), {
                        clss: "p-3 p-sm-5"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-xxl-4 col-xl-4 col-lg-10 mt-5 mt-xl-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_About, {})
            })
        ]
    });
};
/* harmony default export */ const groupDetails_FeedTab = (FeedTab);

// EXTERNAL MODULE: ./components/common/Gallery.tsx + 12 modules
var Gallery = __webpack_require__(58594);
;// CONCATENATED MODULE: ./components/groupDetails/MediaTab.tsx



const MediaTab = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Gallery/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-xxl-4 col-lg-10 mt-5 mt-xl-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_About, {})
            })
        ]
    });
};
/* harmony default export */ const groupDetails_MediaTab = (MediaTab);

// EXTERNAL MODULE: ./components/groupDetails/VideosTab.tsx
var VideosTab = __webpack_require__(55402);
var VideosTab_default = /*#__PURE__*/__webpack_require__.n(VideosTab);
;// CONCATENATED MODULE: ./components/common/GroupDetailsMiddle.tsx






const GroupDetailsMiddle = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "banner-area pages-create mb-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "single-box p-5",
                    children: [
                        children,
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "page-details",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "nav mt-5 pt-4 flex-wrap gap-2 tab-area",
                                role: "tablist",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "nav-link d-center active",
                                            id: "feed-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#feed-tab-pane",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "feed-tab-pane",
                                            "aria-selected": "true",
                                            children: "feed"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "nav-link d-center",
                                            id: "about-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#about-tab-pane",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "about-tab-pane",
                                            "aria-selected": "false",
                                            children: "about"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "nav-link d-center",
                                            id: "connections-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#connections-tab-pane",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "connections-tab-pane",
                                            "aria-selected": "false",
                                            children: "connections"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "nav-link d-center",
                                            id: "media-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#media-tab-pane",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "media-tab-pane",
                                            "aria-selected": "false",
                                            children: "media"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "nav-link d-center",
                                            id: "videos-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#videos-tab-pane",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "videos-tab-pane",
                                            "aria-selected": "false",
                                            children: "videos"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tab-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-pane fade show active",
                        id: "feed-tab-pane",
                        role: "tabpanel",
                        "aria-labelledby": "feed-tab",
                        tabIndex: 0,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_FeedTab, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-pane fade",
                        id: "about-tab-pane",
                        role: "tabpanel",
                        "aria-labelledby": "about-tab",
                        tabIndex: 0,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_AboutTab, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-pane fade",
                        id: "connections-tab-pane",
                        role: "tabpanel",
                        "aria-labelledby": "connections-tab",
                        tabIndex: 0,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_ConnectionsTab, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-pane fade",
                        id: "media-tab-pane",
                        role: "tabpanel",
                        "aria-labelledby": "media-tab",
                        tabIndex: 0,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_MediaTab, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-pane fade",
                        id: "videos-tab-pane",
                        role: "tabpanel",
                        "aria-labelledby": "videos-tab",
                        tabIndex: 0,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((VideosTab_default()), {})
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const common_GroupDetailsMiddle = (GroupDetailsMiddle);


/***/ }),

/***/ 17893:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/MakePost.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);


/***/ }),

/***/ 96683:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// components/common/NewsFeeds.tsx
/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/NewsFeeds.tsx");


/***/ }),

/***/ 55402:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/groupDetails/VideosTab.tsx");


/***/ }),

/***/ 31908:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-10.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 31057:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-10.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 84317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-5.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 13256:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-6.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 89258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-7.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 89530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-8.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 67734:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-8.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 53543:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-9.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 18131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-9.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ })

};
;