"use strict";
exports.id = 9524;
exports.ids = [9524];
exports.modules = {

/***/ 27823:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const CommentAction = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                type: "button",
                className: "dropdown-btn",
                "data-bs-toggle": "dropdown",
                "aria-expanded": "false",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "material-symbols-outlined fs-xxl m-0",
                    children: "more_horiz"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: "dropdown-menu p-4 pt-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "hide_source"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Hide Comments"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "flag"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Report Comments"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CommentAction);


/***/ }),

/***/ 5187:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CommentAction__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27823);
/* harmony import */ var _ReplayReaction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50709);
// components/ui/ParentComment.tsx





const ParentComment = ({ comment  })=>{
    const { authorAvt , authorName , content , replies  } = comment;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${replies.length > 0 ? "parent-comment" : ""} d-flex gap-2 gap-sm-4`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "avatar-item d-center align-items-baseline",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "avatar-img max-un",
                    src: authorAvt || "/default-avatar.png",
                    alt: authorName || "User",
                    width: 40,
                    height: 40
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "info-item active",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "top-area px-4 py-3 d-flex gap-3 align-items-start justify-content-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "title-area",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "m-0 mb-3",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/public-profile/post",
                                            children: [
                                                authorName || "Unknown User",
                                                " "
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "mdtxt",
                                        children: content
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "btn-group dropend cus-dropdown",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CommentAction__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ReplayReaction__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ParentComment);


/***/ }),

/***/ 59286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ui_Post)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/ui/PostAction.tsx

const PostAction = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "btn-group cus-dropdown dropend",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                className: "dropdown-btn px-2",
                "data-bs-toggle": "dropdown",
                "aria-expanded": "false",
                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "material-symbols-outlined fs-xxl m-0",
                    children: "more_horiz"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "dropdown-menu p-4 pt-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "chat"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Message"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "person_remove"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Unfollow"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "bookmark_add"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Save Post"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "lock"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Block User"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "flag"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Report User"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            style: {
                                color: "#FF0000"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    style: {
                                        color: "#FF0000"
                                    },
                                    children: "cancel"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Cancel"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ui_PostAction = (PostAction);

;// CONCATENATED MODULE: ./components/ui/Post.tsx
// components/ui/Post.tsx (for reference)




const Post = ({ post  })=>{
    const { description , image , hashtags , mentionUsers , mediaType , poll , postGallary , authorName ="Unknown User" , authorAvt ="/default-avatar.png"  } = post;
    const renderMedia = ()=>{
        if (!mediaType || mediaType === "text") return null;
        if (mediaType === "poll" && poll) {
            const totalVotes = poll.reduce((sum, option)=>sum + option.votes, 0);
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "poll-area my-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "poll-label",
                        children: "Poll"
                    }),
                    poll.map((option)=>{
                        const percentage = totalVotes > 0 ? option.votes / totalVotes * 100 : 0;
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "poll-option",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex justify-content-between align-items-center mb-1",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "poll-option-text",
                                            children: option.text
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "poll-option-votes",
                                            children: [
                                                option.votes,
                                                " votes (",
                                                percentage.toFixed(1),
                                                "%)"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "poll-progress-bar",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "poll-progress-fill",
                                        style: {
                                            width: `${percentage}%`
                                        }
                                    })
                                })
                            ]
                        }, option.id);
                    })
                ]
            });
        }
        const media = postGallary && postGallary.length > 0 ? postGallary.map((item)=>item.filename) : image ? [
            image
        ] : [];
        if (!media || media.length === 0) {
            return /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-danger",
                children: "Media not found"
            });
        }
        if (mediaType === "image" || mediaType === "gif") {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `post-img ${media.length > 1 ? "d-flex justify-content-between flex-wrap gap-2 gap-lg-3" : ""}`,
                children: media.length > 1 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "single",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: media[0],
                                alt: "post media",
                                width: 300,
                                height: 300
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "single d-grid gap-3",
                            children: media.slice(1).map((src, index)=>/*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: src,
                                    alt: "post media",
                                    width: 150,
                                    height: 150
                                }, index))
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: media[0],
                    alt: "post media",
                    className: "w-100",
                    width: 600,
                    height: 400
                })
            });
        }
        if (mediaType === "video") {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "post-video",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("video", {
                    controls: true,
                    className: "w-100",
                    style: {
                        maxHeight: "400px"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("source", {
                            src: media[0],
                            type: "video/mp4"
                        }),
                        "Your browser does not support the video tag."
                    ]
                })
            });
        }
        if (mediaType === "pdf") {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "post-pdf",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("iframe", {
                    src: media[0],
                    width: "100%",
                    height: "500px",
                    title: "PDF Document",
                    style: {
                        border: "none"
                    },
                    children: [
                        "Your browser does not support PDFs. Please download the PDF to view it: ",
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: media[0],
                            children: "Download PDF"
                        }),
                        "."
                    ]
                })
            });
        }
        return /*#__PURE__*/ jsx_runtime_.jsx("p", {
            className: "text-danger",
            children: "Unsupported media type"
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "top-area pb-5",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "profile-area d-center justify-content-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "avatar-item d-flex gap-3 align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "avatar position-relative before-element-target",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "avatar-img max-un",
                                    src: authorAvt,
                                    alt: authorName,
                                    width: 50,
                                    height: 50
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "info-area",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                        className: "m-0",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/public-profile/post",
                                            children: authorName
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mdtxt status",
                                        children: "@santhosh_007"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "btn-group cus-dropdown",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_PostAction, {})
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "py-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "description",
                        children: description || ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "hastag d-flex gap-2",
                        children: hashtags?.map((itm)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "#",
                                children: [
                                    "#",
                                    itm
                                ]
                            }, itm))
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "mentions d-flex gap-2",
                        children: mentionUsers?.map((user)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "#",
                                children: [
                                    "@",
                                    user
                                ]
                            }, user))
                    })
                ]
            }),
            renderMedia()
        ]
    });
};
/* harmony default export */ const ui_Post = (Post);


/***/ }),

/***/ 50709:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34338);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(68985);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(61003);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__  auto */ 



const ReplayReaction = ()=>{
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const isMobile = (0,react_responsive__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)({
        query: "(max-width: 575px)"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: "like-share d-flex gap-6 mt-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: "d-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "mdtxt",
                            children: "Like"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: "d-center flex-column",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "mdtxt reply-btn",
                            onClick: ()=>setExpanded(!expanded),
                            children: "Reply"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: "d-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "mdtxt",
                            children: "Share"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                action: "#",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__/* .AnimatePresence */ .M, {
                    initial: false,
                    children: expanded && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion.div */ .E.div, {
                        initial: "collapsed",
                        animate: "open",
                        exit: "collapsed",
                        variants: {
                            open: {
                                opacity: 1,
                                height: "auto",
                                marginTop: isMobile ? 10 : 24
                            },
                            collapsed: {
                                opacity: 0,
                                height: 0,
                                marginTop: 0
                            }
                        },
                        transition: {
                            duration: 0.8,
                            ease: [
                                0.04,
                                0.62,
                                0.23,
                                0.98
                            ]
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                placeholder: "Write a comment..",
                                className: "py-3",
                                required: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "cmn-btn px-2 px-sm-5 px-lg-6",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "material-symbols-outlined mat-icon m-0 fs-xxl",
                                    children: "near_me"
                                })
                            })
                        ]
                    }, "content")
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReplayReaction);


/***/ }),

/***/ 73580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CommentAction__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27823);
/* harmony import */ var _ReplayReaction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50709);
// components/ui/SiblingComment.tsx





const SiblingComment = ({ reply , clss ="sibling-comment"  })=>{
    const { authorAvt , authorName , content  } = reply;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${clss} comment-item-nested single-comment-area mt-4 mt-sm-7 ms-13 ms-sm-15`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex gap-2 gap-sm-4 align-items-baseline",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "avatar-item",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "avatar-img max-un",
                        src: authorAvt || "/default-avatar.png",
                        alt: authorName || "User",
                        width: 30,
                        height: 30
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "info-item",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "top-area px-4 py-3 d-flex gap-3 align-items-start justify-content-between",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "title-area",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: "m-0 mb-3",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/public-profile/post",
                                                children: [
                                                    authorName || "Unknown User",
                                                    " "
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mdtxt",
                                            children: content
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "btn-group dropend cus-dropdown",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CommentAction__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ReplayReaction__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SiblingComment);


/***/ }),

/***/ 94786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_images_add_post_avatar_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7953);




const WriteComment = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        action: "#",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex mt-5 gap-3",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "profile-box d-none d-xxl-block",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "#",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                            src: _public_images_add_post_avatar_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                            className: "max-un",
                            alt: "icon"
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "form-content input-area py-1 d-flex gap-2 align-items-center w-100",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            placeholder: "Write a comment..",
                            required: true
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "file-input d-flex gap-1 gap-md-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "file-upload",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                        className: "file",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "file",
                                                required: true
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "file-custom border-0 d-grid text-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined mat-icon m-0 xxltxt",
                                                    children: "gif_box"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "file-upload",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                        className: "file",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "file",
                                                required: true
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "file-custom border-0 d-grid text-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined mat-icon m-0 xxltxt",
                                                    children: "perm_media"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mood-area",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "material-symbols-outlined mat-icon m-0 xxltxt",
                                        children: "mood"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "btn-area d-flex",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        type: "submit",
                        className: "cmn-btn px-2 px-sm-5 px-lg-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-symbols-outlined mat-icon m-0 fs-xxl",
                            children: "near_me"
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WriteComment);


/***/ }),

/***/ 39970:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ useAppSelector),
/* harmony export */   "T": () => (/* binding */ useAppDispatch)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1560);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

const useAppDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)();
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;


/***/ })

};
;