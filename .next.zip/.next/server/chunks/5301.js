"use strict";
exports.id = 5301;
exports.ids = [5301];
exports.modules = {

/***/ 63881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/node_modules/next/dist/client/image.js");
 //# sourceMappingURL=image.js.map


/***/ }),

/***/ 42301:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/node_modules/next/dist/client/link.js");
 //# sourceMappingURL=link.js.map


/***/ }),

/***/ 62208:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


module.exports = __webpack_require__(63881);


/***/ }),

/***/ 42585:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


module.exports = __webpack_require__(42301);


/***/ }),

/***/ 16969:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-1.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ })

};
;