"use strict";
exports.id = 7579;
exports.ids = [7579];
exports.modules = {

/***/ 3272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Vedios)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/images/video-bg-1.png
/* harmony default export */ const video_bg_1 = ({"src":"/_next/static/media/video-bg-1.c94e5950.png","height":239,"width":441,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAElBMVEXy8vLd3d3u7u7X19fQ0NDGxsZlkYJ4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgYmIAASYGJkYWZmZWZgYkBliGgQkAA+0ANQERY40AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/images/video-bg-2.png
/* harmony default export */ const video_bg_2 = ({"src":"/_next/static/media/video-bg-2.c94e5950.png","height":239,"width":441,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAElBMVEXy8vLd3d3u7u7X19fQ0NDGxsZlkYJ4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgYmIAASYGJkYWZmZWZgYkBliGgQkAA+0ANQERY40AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/images/video-bg-3.png
/* harmony default export */ const video_bg_3 = ({"src":"/_next/static/media/video-bg-3.c94e5950.png","height":239,"width":441,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAElBMVEXy8vLd3d3u7u7X19fQ0NDGxsZlkYJ4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgYmIAASYGJkYWZmZWZgYkBliGgQkAA+0ANQERY40AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/images/video-bg-4.png
/* harmony default export */ const video_bg_4 = ({"src":"/_next/static/media/video-bg-4.c94e5950.png","height":239,"width":441,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAElBMVEXy8vLd3d3u7u7X19fQ0NDGxsZlkYJ4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgYmIAASYGJkYWZmZWZgYkBliGgQkAA+0ANQERY40AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/images/video-bg-5.png
/* harmony default export */ const video_bg_5 = ({"src":"/_next/static/media/video-bg-5.c94e5950.png","height":239,"width":441,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAElBMVEXy8vLd3d3u7u7X19fQ0NDGxsZlkYJ4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgYmIAASYGJkYWZmZWZgYkBliGgQkAA+0ANQERY40AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/images/video-bg-6.png
/* harmony default export */ const video_bg_6 = ({"src":"/_next/static/media/video-bg-6.c94e5950.png","height":239,"width":441,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAElBMVEXy8vLd3d3u7u7X19fQ0NDGxsZlkYJ4AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgYmIAASYGJkYWZmZWZgYkBliGgQkAA+0ANQERY40AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./components/common/Vedios.tsx








const Vedios = ({ setOpen  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-xxl-8 col-xl-8",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "single-box p-5",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row cus-mar",
                children: [
                    video_bg_1,
                    video_bg_2,
                    video_bg_3,
                    video_bg_4,
                    video_bg_5,
                    video_bg_6
                ].map((itm, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-md-6",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "single-box",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "magnific-area position-relative d-flex align-items-center justify-content-around",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "bg-area w-100",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "bg-item w-100",
                                            src: itm,
                                            alt: "image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "content-area text-center position-absolute d-flex align-items-center justify-content-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "content-box",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: "mfp-iframe popupvideo d-flex align-items-center justify-content-center",
                                                onClick: ()=>setOpen(true),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "material-symbols-outlined mat-icon fs-1",
                                                    children: "play_arrow"
                                                })
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    }, i))
            })
        })
    });
};
/* harmony default export */ const common_Vedios = (Vedios);


/***/ }),

/***/ 66594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const About = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "cus-scrollbar",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "sidebar-wrapper d-flex al-item flex-wrap justify-content-end justify-content-xl-center flex-column flex-md-row flex-xl-column flex gap-6",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "sidebar-area p-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "d-inline-flex",
                            children: "About"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "mdtxt descript",
                        children: "Lorem ipsum dolor sit amet cons all Ofectetur. Pellentesque ipsum necat congue pretium cursus orci. It Commodo donec tellus lacus pellentesque sagittis habitant quam amet praesent."
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "d-grid gap-2 mt-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "schedule"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mdtxt",
                                        children: "Always"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "flag"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mdtxt",
                                        children: "31k Member"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "language"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mdtxt",
                                        children: "Public"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);


/***/ })

};
;