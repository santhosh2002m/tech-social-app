"use strict";
exports.id = 7023;
exports.ids = [7023];
exports.modules = {

/***/ 7023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_CrudAction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18854);
/* harmony import */ var _ui_PrivacyAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13303);



const bioData = [
    {
        id: 1,
        type: "Developer",
        icon: "integration_instructions",
        class: ""
    },
    {
        id: 2,
        type: "Master's degree",
        icon: "school",
        class: ""
    },
    {
        id: 3,
        type: "test@mail.com",
        icon: "flag",
        class: "link"
    },
    {
        id: 4,
        type: "www.wisoky.com",
        icon: "language",
        class: "link"
    },
    {
        id: 5,
        type: "(316) 555-0116",
        icon: "call",
        class: ""
    },
    {
        id: 6,
        type: "USA",
        icon: "pin_drop",
        class: ""
    },
    {
        id: 7,
        type: "775 Rolling Green Rd.",
        icon: "house",
        class: ""
    }
];
const BioContent = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "single-box p-3 p-sm-5",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "head-area text-start",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                        children: "Bio"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "mdtxt mt-6",
                        children: "“Lorem ipsum dolor sit amet consectetur. Nec donec vestibulum eleifend lectus ipsum ultrices et dictum”."
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "d-grid gap-3 mt-4",
                children: bioData.map((itm)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "d-center gap-3 justify-content-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "info-area d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: itm.icon
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: `mdtxt ${itm.class}`,
                                        children: itm.type
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "input-item d-center text-start",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_PrivacyAction__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_CrudAction__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                                ]
                            })
                        ]
                    }, itm.id))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BioContent);


/***/ })

};
;