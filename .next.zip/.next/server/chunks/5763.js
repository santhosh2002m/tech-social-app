"use strict";
exports.id = 5763;
exports.ids = [5763];
exports.modules = {

/***/ 5763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Connections)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
;// CONCATENATED MODULE: ./public/images/followers-img-1.png
/* harmony default export */ const followers_img_1 = ({"src":"/_next/static/media/followers-img-1.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-10.png
/* harmony default export */ const followers_img_10 = ({"src":"/_next/static/media/followers-img-10.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-11.png
/* harmony default export */ const followers_img_11 = ({"src":"/_next/static/media/followers-img-11.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-12.png
/* harmony default export */ const followers_img_12 = ({"src":"/_next/static/media/followers-img-12.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-13.png
/* harmony default export */ const followers_img_13 = ({"src":"/_next/static/media/followers-img-13.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-14.png
/* harmony default export */ const followers_img_14 = ({"src":"/_next/static/media/followers-img-14.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-2.png
/* harmony default export */ const followers_img_2 = ({"src":"/_next/static/media/followers-img-2.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-3.png
/* harmony default export */ const followers_img_3 = ({"src":"/_next/static/media/followers-img-3.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-4.png
/* harmony default export */ const followers_img_4 = ({"src":"/_next/static/media/followers-img-4.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-5.png
/* harmony default export */ const followers_img_5 = ({"src":"/_next/static/media/followers-img-5.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-6.png
/* harmony default export */ const followers_img_6 = ({"src":"/_next/static/media/followers-img-6.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-7.png
/* harmony default export */ const followers_img_7 = ({"src":"/_next/static/media/followers-img-7.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-8.png
/* harmony default export */ const followers_img_8 = ({"src":"/_next/static/media/followers-img-8.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/followers-img-9.png
/* harmony default export */ const followers_img_9 = ({"src":"/_next/static/media/followers-img-9.2b592d63.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEXu7u709PTNzc3U1NTJycnOzs7DkcDlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHUlEQVR4nGNgwAIYGRkZwQwWZiYmKIMVwoBLoQEABOQAIiGhc54AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./data/followData.ts














const followData = [
    {
        id: 1,
        user_name: "Cameron Williamson",
        user_avt: followers_img_1
    },
    {
        id: 2,
        user_name: "Esther Howard",
        user_avt: followers_img_2
    },
    {
        id: 3,
        user_name: "Brooklyn Simmons",
        user_avt: followers_img_3
    },
    {
        id: 4,
        user_name: "Courtney Henry",
        user_avt: followers_img_4
    },
    {
        id: 5,
        user_name: "Eleanor Pena",
        user_avt: followers_img_5
    },
    {
        id: 6,
        user_name: "Arlene McCoy",
        user_avt: followers_img_6
    },
    {
        id: 7,
        user_name: "Devon Lane",
        user_avt: followers_img_7
    },
    {
        id: 8,
        user_name: "Ronald Richards",
        user_avt: followers_img_8
    },
    {
        id: 9,
        user_name: "Kathryn Murphy",
        user_avt: followers_img_9
    },
    {
        id: 10,
        user_name: "Darrell Steward",
        user_avt: followers_img_10
    },
    {
        id: 11,
        user_name: "Guy Hawkins",
        user_avt: followers_img_11
    },
    {
        id: 12,
        user_name: "Floyd Miles",
        user_avt: followers_img_12
    },
    {
        id: 13,
        user_name: "Cameron Williamson",
        user_avt: followers_img_13
    },
    {
        id: 14,
        user_name: "Wade Warren",
        user_avt: followers_img_14
    }
];
/* harmony default export */ const data_followData = (followData);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(62208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(42585);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/ui/ContactAction.tsx
var ContactAction = __webpack_require__(38445);
;// CONCATENATED MODULE: ./components/cards/FollowCard.tsx
// FollowCard.tsx




const FollowCard = ({ data  })=>{
    const { id , user_avt , user_name  } = data;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "single-box member-single p-3",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "profile-area d-center justify-content-between",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "avatar-item d-flex gap-3 align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "avatar-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "avatar-img max-un",
                                src: user_avt,
                                alt: "avatar"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "info-area text-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "m-0",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/public-profile/post",
                                        children: user_name
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "mdtxt status",
                                    children: "10 Mutual Friends"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ContactAction/* default */.Z, {
                    sectionType: "followings"
                })
            ]
        })
    });
};
/* harmony default export */ const cards_FollowCard = (FollowCard);

;// CONCATENATED MODULE: ./components/groupDetails/FollowersTab.tsx



const FollowersTab = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "search-area d-center my-7 flex-wrap gap-2 justify-content-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "total-followers",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            children: "30k Followers"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("form", {
                        action: "#",
                        className: "d-flex align-items-stretch justify-content-between gap-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "input-area py-2 w-100 gap-2 d-flex align-items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "search"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    placeholder: "Search"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    data_followData.map((data)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-md-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cards_FollowCard, {
                                data: data
                            })
                        }, data.id)),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 my-5 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "cmn-btn alt third fw-600",
                            children: "Load More"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const groupDetails_FollowersTab = (FollowersTab);

;// CONCATENATED MODULE: ./components/groupDetails/FollowingTab.tsx



const FollowingTab = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "search-area d-center my-7 flex-wrap gap-2 justify-content-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "total-followers",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            children: "30k Followers"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("form", {
                        action: "#",
                        className: "d-flex align-items-stretch justify-content-between gap-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "input-area py-2 w-100 gap-2 d-flex align-items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "search"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    placeholder: "Search"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    data_followData.slice(7, 14).map((data)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-md-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cards_FollowCard, {
                                data: data
                            })
                        }, data.id)),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 my-5 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "cmn-btn alt third fw-600",
                            children: "Load More"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const groupDetails_FollowingTab = (FollowingTab);

;// CONCATENATED MODULE: ./components/common/Connections.tsx



const Connections = ({ clss ="col-xxl-8"  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: clss,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "single-box p-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "nav flex-wrap gap-2 tab-area",
                    role: "tablist",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item",
                            role: "presentation",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "nav-link d-center active",
                                id: "followers-tab",
                                "data-bs-toggle": "tab",
                                "data-bs-target": "#followers-tab-pane",
                                type: "button",
                                role: "tab",
                                "aria-controls": "followers-tab-pane",
                                "aria-selected": "true",
                                children: "followers"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item",
                            role: "presentation",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "nav-link",
                                id: "following-tab",
                                "data-bs-toggle": "tab",
                                "data-bs-target": "#following-tab-pane",
                                type: "button",
                                role: "tab",
                                "aria-controls": "following-tab-pane",
                                "aria-selected": "false",
                                tabIndex: 0,
                                children: "following"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tab-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-pane fade show active",
                        id: "followers-tab-pane",
                        role: "tabpanel",
                        "aria-labelledby": "followers-tab",
                        tabIndex: 0,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_FollowersTab, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-pane fade",
                        id: "following-tab-pane",
                        role: "tabpanel",
                        "aria-labelledby": "following-tab",
                        tabIndex: 0,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(groupDetails_FollowingTab, {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const common_Connections = (Connections);


/***/ })

};
;