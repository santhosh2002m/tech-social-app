"use strict";
exports.id = 8594;
exports.ids = [8594];
exports.modules = {

/***/ 58594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Gallery)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(62208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/images/photo-gallery-1.png
/* harmony default export */ const photo_gallery_1 = ({"src":"/_next/static/media/photo-gallery-1.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-10.png
/* harmony default export */ const photo_gallery_10 = ({"src":"/_next/static/media/photo-gallery-10.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-11.png
/* harmony default export */ const photo_gallery_11 = ({"src":"/_next/static/media/photo-gallery-11.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-12.png
/* harmony default export */ const photo_gallery_12 = ({"src":"/_next/static/media/photo-gallery-12.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-2.png
/* harmony default export */ const photo_gallery_2 = ({"src":"/_next/static/media/photo-gallery-2.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-3.png
/* harmony default export */ const photo_gallery_3 = ({"src":"/_next/static/media/photo-gallery-3.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-4.png
/* harmony default export */ const photo_gallery_4 = ({"src":"/_next/static/media/photo-gallery-4.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-5.png
/* harmony default export */ const photo_gallery_5 = ({"src":"/_next/static/media/photo-gallery-5.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-6.png
/* harmony default export */ const photo_gallery_6 = ({"src":"/_next/static/media/photo-gallery-6.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-7.png
/* harmony default export */ const photo_gallery_7 = ({"src":"/_next/static/media/photo-gallery-7.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-8.png
/* harmony default export */ const photo_gallery_8 = ({"src":"/_next/static/media/photo-gallery-8.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/photo-gallery-9.png
/* harmony default export */ const photo_gallery_9 = ({"src":"/_next/static/media/photo-gallery-9.947fbbd3.png","height":208,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAFVBMVEXz8/Pu7u7W1tbd3d3Dw8PHx8e/v799tWb+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAJklEQVR4nGNghAIGRgYwYGRgZGZjYmJhYmBgZGZhYmJlQpaCKgYABpQAPTh+PPQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./components/common/Gallery.tsx














const Gallery = ({ clss ="col-xxl-8"  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: clss,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "single-box p-5",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row cus-mar",
                children: [
                    photo_gallery_1,
                    photo_gallery_2,
                    photo_gallery_3,
                    photo_gallery_4,
                    photo_gallery_5,
                    photo_gallery_6,
                    photo_gallery_7,
                    photo_gallery_8,
                    photo_gallery_9,
                    photo_gallery_10,
                    photo_gallery_11,
                    photo_gallery_12
                ].map((itm, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-md-4 col-6",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "single-box",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "w-100",
                                src: itm,
                                alt: "image"
                            })
                        })
                    }, i))
            })
        })
    });
};
/* harmony default export */ const common_Gallery = (Gallery);


/***/ })

};
;