exports.id = 5867;
exports.ids = [5867];
exports.modules = {

/***/ 36976:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/menu/GroupLeftMenu.tsx");


/***/ }),

/***/ 80115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LM": () => (/* binding */ adminTools)
/* harmony export */ });
/* unused harmony exports pageAdminTools, friendLeftMenu, homeLeftMenu */
const pageAdminTools = (/* unused pure expression or super */ null && ([
    [
        "account_circle",
        "Dashboard",
        "/pages-dashboard"
    ],
    [
        "group",
        "Your Pages",
        "/pages-your"
    ],
    [
        "bookmark_add",
        "Privacy",
        "/pages-privacy"
    ],
    [
        "settings",
        "Settings",
        "/pages-setting"
    ]
]));
const adminTools = [
    [
        "account_circle",
        "Admin Assist",
        "/group-admin-assist"
    ],
    [
        "group",
        "Member request",
        "/group-member-request"
    ],
    [
        "checklist",
        "Post approvals",
        "/group-posts"
    ],
    [
        "workspace_premium",
        "Event",
        "/group-event"
    ],
    [
        "workspaces",
        "Group activity",
        "/group-activity"
    ],
    [
        "bookmark_add",
        "Privacy",
        "/group-privacy"
    ],
    [
        "settings",
        "Settings",
        "/group-setting"
    ]
];
const friendLeftMenu = (/* unused pure expression or super */ null && ([
    [
        "person",
        "Friend Request",
        "/friend-request"
    ],
    [
        "person_add",
        "Suggestions",
        "/suggestions"
    ],
    [
        "person",
        "All Friend",
        "/all-friend"
    ],
    [
        "lock",
        "Block List",
        "/block-list"
    ]
]));
// data/sidbarData.ts
// data/sidbarData.ts
const homeLeftMenu = (/* unused pure expression or super */ null && ([
    [
        "home",
        "Home",
        "/"
    ],
    [
        "chat",
        "Chats",
        "/chats"
    ],
    [
        "add",
        "Post",
        "/posts"
    ],
    [
        "travel_explore",
        "Explore AI",
        "/explore-ai"
    ],
    [
        "thumb_up_alt",
        "Liked",
        "/liked"
    ],
    [
        "reply",
        "Shared ",
        "/shared"
    ],
    [
        "mode_comment",
        "Commented ",
        "/commented"
    ],
    [
        "alternate_email",
        "Mentioned ",
        "/mentioned"
    ],
    [
        "turned_in",
        "Saved ",
        "/saved"
    ],
    [
        "quiz",
        "FAQ",
        "/faq"
    ],
    [
        "support_agent",
        "Support",
        "/support"
    ],
    [
        "subscriptions",
        "Subscriptions",
        "/subscription"
    ]
]));


/***/ })

};
;