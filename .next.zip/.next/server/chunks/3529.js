"use strict";
exports.id = 3529;
exports.ids = [3529];
exports.modules = {

/***/ 33529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const ContactAction = ({ sectionType , actionList  })=>{
    // Define default actions with updated icons
    const defaultActionLists = {
        followers: [
            [
                "Remove Follower",
                "block"
            ],
            [
                "Message",
                "mail"
            ]
        ],
        followings: [
            [
                "Unfollow",
                "block"
            ],
            [
                "Message",
                "mail"
            ]
        ]
    };
    // Use actionList if provided, otherwise fall back to defaultActionLists[sectionType]
    const actions = actionList || defaultActionLists[sectionType];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "btn-group cus-dropdown dropend",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                type: "button",
                className: "d-flex dropdown-btn px-2",
                "data-bs-toggle": "dropdown",
                "aria-expanded": "false",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "material-symbols-outlined fs-xxl m-0",
                    children: "more_horiz"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "dropdown-menu p-4 pt-2",
                children: actions?.map(([itm, icon], i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "droplist d-flex align-items-center gap-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: icon
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: itm
                                })
                            ]
                        })
                    }, i))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContactAction);


/***/ })

};
;