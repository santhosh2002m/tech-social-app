"use strict";
exports.id = 6587;
exports.ids = [6587];
exports.modules = {

/***/ 1606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Settings)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(62208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/ui/CrudAction.tsx
var CrudAction = __webpack_require__(18854);
// EXTERNAL MODULE: ./components/ui/PrivacyAction.tsx
var PrivacyAction = __webpack_require__(13303);
;// CONCATENATED MODULE: ./public/images/profile-cover.png
/* harmony default export */ const profile_cover = ({"src":"/_next/static/media/profile-cover.0924d4a0.png","height":163,"width":902,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAAD1BMVEXY2NjMzMy+vr65ubny8vIIRHTWAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAEUlEQVR4nGNgYWBmZGBiYAEAAEoAD8nZxCgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
// EXTERNAL MODULE: ./public/images/profile-picture.png
var profile_picture = __webpack_require__(84331);
;// CONCATENATED MODULE: ./components/common/Settings.tsx






const Settings = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "single-box p-sm-5 p-3",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row gap-6",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xxl-2 col-md-3 col-sm-5 col-6 pe-0",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "upload-single",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "head-area mb-2 text-start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            children: "Profile Image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "profile-picture text-start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "preview-image w-100",
                                            src: profile_picture/* default */.Z,
                                            alt: "Preview Image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "file-upload",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                            className: "file text-start mt-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "file",
                                                    required: true
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "cmn-btn",
                                                    children: "Change Profile"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-md-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "upload-single cover-img",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "head-area mb-2 text-start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            children: "Cover Image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "profile-picture text-start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: "preview-image w-100",
                                            src: profile_cover,
                                            alt: "Preview Image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "file-upload",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                            className: "file text-start mt-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "file",
                                                    required: true
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "cmn-btn",
                                                    children: "Change Cover photo"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "single-box text-start p-sm-5 p-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "head-area mb-6",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            children: "General Information "
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("form", {
                        className: "text-center d-grid gap-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "single-input text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "name",
                                                children: "Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "input-area second",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "text",
                                                    placeholder: "Type name",
                                                    required: true
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "single-input text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "number",
                                                children: "Number"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "input-area second",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "text",
                                                    placeholder: "Number",
                                                    required: true
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "single-input text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "Email",
                                                children: "Email"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "input-area second",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "text",
                                                    placeholder: "Email",
                                                    required: true
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-7 mt-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "single-input text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                children: "Bio"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "mdtxt mt-6",
                                                children: "“Lorem ipsum dolor sit amet consectetur. Nec donec vestibulum eleifend lectus ipsum ultrices et dictum”."
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-5 mt-4 d-center justify-content-end",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "single-input d-center text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(PrivacyAction/* default */.Z, {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx(CrudAction/* default */.Z, {})
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-12 mt-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "btn-area text-end",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "submit",
                                            className: "cmn-btn",
                                            children: "Saved Change"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const common_Settings = (Settings);


/***/ }),

/***/ 37437:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/profile-cover.0924d4a0.png","height":163,"width":902,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAAD1BMVEXY2NjMzMy+vr65ubny8vIIRHTWAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAEUlEQVR4nGNgYWBmZGBiYAEAAEoAD8nZxCgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});

/***/ })

};
;