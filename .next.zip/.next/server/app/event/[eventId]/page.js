(() => {
var exports = {};
exports.id = 8968;
exports.ids = [8968];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 95232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 81983:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(75183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(15815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(50515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'event',
        {
        children: [
        '[eventId]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71736)), "/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/event/[eventId]/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45596)), "/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/event/[eventId]/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/event/[eventId]/page"
  

/***/ }),

/***/ 21207:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 40408, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 20053, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19461));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 14352));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91504));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86406));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50951));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56833));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61688));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56440));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99820));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89628));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 87041));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67048));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46387));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60640));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 18223))

/***/ }),

/***/ 71736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ EventDetails)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./data/eventData.ts + 9 modules
var eventData = __webpack_require__(34185);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(62208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(42585);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/cards/EventCard.tsx
var EventCard = __webpack_require__(9571);
// EXTERNAL MODULE: ./components/menu/HomeLeft.tsx
var HomeLeft = __webpack_require__(95244);
var HomeLeft_default = /*#__PURE__*/__webpack_require__.n(HomeLeft);
// EXTERNAL MODULE: ./components/ui/ContactAction.tsx
var ContactAction = __webpack_require__(38445);
// EXTERNAL MODULE: ./public/images/avatar-2.png
var avatar_2 = __webpack_require__(14969);
// EXTERNAL MODULE: ./public/images/avatar-3.png
var avatar_3 = __webpack_require__(60072);
// EXTERNAL MODULE: ./public/images/avatar-4.png
var avatar_4 = __webpack_require__(82688);
;// CONCATENATED MODULE: ./components/eventDetails/AboutTab.tsx






const AboutTab = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "row gap-5 gap-xl-0",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-xl-7",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "friends-list d-flex gap-3 align-items-center text-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "d-flex align-items-center justify-content-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: avatar_2/* default */.Z,
                                            alt: "image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: avatar_3/* default */.Z,
                                            alt: "image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: avatar_4/* default */.Z,
                                            alt: "image"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "mdtxt d-center",
                                children: "476 People Going"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "d-grid gap-2 my-5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "schedule"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mdtxt",
                                        children: "6 Day"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "flag"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mdtxt",
                                        children: "Event by PLM (People Love Music)"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "d-flex align-items-center gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "material-symbols-outlined mat-icon",
                                        children: "language"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mdtxt",
                                        children: "Public"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "time-schedule",
                        children: "DEC 2, 2022 AT 10:30 - 7:30 PM"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "description-box mt-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mdtxt",
                                children: "Are you missing the festive vibe toward the end of the year? ITCRC is thrilled to announce that it has organized the year's largest online event, Kings Outfit Presents TechnoGaze 1.0 powered by UVTR So sharpen your skills and prepare to be a part of this event while also enjoying the festive atmosphere."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "segment-area mt-7",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mdtxt",
                                        children: "The event will have some amazing segments:"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "mdtxt",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Programming contest"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Graphics Design"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Gaming (Brawlhalla)"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Tech Quiz & IT Olympiad"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "PowerPoint Presentation."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mdtxt",
                                        children: "Wants to energize the vibe?"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mdtxt",
                                        children: "Winners will be given certificate, crests & many more."
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-xl-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "find-tickets p-5",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            className: "head-area",
                            children: "Tickets"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "#",
                            className: "cmn-btn mt-5 mb-4 w-100 d-center gap-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "material-symbols-outlined mat-icon",
                                    children: "add"
                                }),
                                "Find Tickets"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                            src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d142723.46117209745!2d-122.36259993497053!3d37.7719269407752!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80859a6d00690021%3A0x4a501367f076adff!2sSan%20Francisco%2C%20CA%2C%20USA!5e0!3m2!1sen!2sbd!4v1677037248094!5m2!1sen!2sbd"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mdtxt",
                            children: "International Convention City, (ICCB)"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const eventDetails_AboutTab = (AboutTab);

// EXTERNAL MODULE: ./components/common/NewsFeeds.tsx
var NewsFeeds = __webpack_require__(96683);
var NewsFeeds_default = /*#__PURE__*/__webpack_require__.n(NewsFeeds);
;// CONCATENATED MODULE: ./components/eventDetails/DiscussionTab.tsx


const DiscussionTab = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "post-item d-flex flex-column gap-5 gap-md-7",
        id: "news-feed",
        children: /*#__PURE__*/ jsx_runtime_.jsx((NewsFeeds_default()), {
            reaction: "pt-4"
        })
    });
};
/* harmony default export */ const eventDetails_DiscussionTab = (DiscussionTab);

;// CONCATENATED MODULE: ./public/images/event-cover-img.png
/* harmony default export */ const event_cover_img = ({"src":"/_next/static/media/event-cover-img.fc9aecbe.png","height":500,"width":966,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAD1BMVEXz8/Pb29vCwsLV1dXt7e1xLeDOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAGklEQVR4nGNgYQADFgYGRiZmZiZGBgQDJgUAAvQAKbyR5DUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./components/eventDetails/EventDetailsMain.tsx










const EventDetailsMain = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        className: "main-content",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-3 col-lg-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((HomeLeft_default()), {
                            clss: "d-lg-none"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-xl-9 col-lg-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "banner-area mb-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "single-box",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "avatar-box position-relative",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                className: "avatar-img w-100",
                                                src: event_cover_img,
                                                alt: "image"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "abs-area position-absolute top-0 p-3 p-lg-5 p-xl-10",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "date-area mdtxt",
                                                    children: "2 DEC 2022"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "abs-area position-absolute bottom-0 p-3 p-lg-5 p-xl-10 pb-3 pb-lg-5 pb-xl-8",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    children: "Martio Music Event I Biggest Music Festival"
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "details-area p-5 mb-5",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "top-area pb-6 mb-6 d-center flex-wrap gap-3 justify-content-between",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                className: "nav flex-wrap gap-2 tab-area",
                                                role: "tablist",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        role: "presentation",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "nav-link d-center active",
                                                            id: "about-tab",
                                                            "data-bs-toggle": "tab",
                                                            "data-bs-target": "#about-tab-pane",
                                                            type: "button",
                                                            role: "tab",
                                                            "aria-controls": "about-tab-pane",
                                                            "aria-selected": "true",
                                                            children: "about"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        role: "presentation",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "nav-link d-center",
                                                            id: "discussion-tab",
                                                            "data-bs-toggle": "tab",
                                                            "data-bs-target": "#discussion-tab-pane",
                                                            type: "button",
                                                            role: "tab",
                                                            "aria-controls": "discussion-tab-pane",
                                                            "aria-selected": "false",
                                                            children: "discussion"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "btn-item d-center flex-wrap gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "#",
                                                        className: "cmn-btn d-center third gap-1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "material-symbols-outlined mat-icon fs-xl",
                                                                children: "grade"
                                                            }),
                                                            "Interested"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "#",
                                                        className: "cmn-btn third gap-1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "material-symbols-outlined mat-icon fs-xl",
                                                                children: "add_box"
                                                            }),
                                                            "Invite"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "#",
                                                        className: "cmn-btn third gap-1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "material-symbols-outlined mat-icon fs-xl",
                                                                children: "google_plus_reshare"
                                                            }),
                                                            "Share"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ContactAction/* default */.Z, {
                                                        sectionType: "followings",
                                                        actionList: [
                                                            [
                                                                "Unfollow",
                                                                "person_remove"
                                                            ],
                                                            [
                                                                "Hide",
                                                                "hide_source"
                                                            ]
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "tab-content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "tab-pane fade show active",
                                                id: "about-tab-pane",
                                                role: "tabpanel",
                                                "aria-labelledby": "about-tab",
                                                tabIndex: 0,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(eventDetails_AboutTab, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "tab-pane fade",
                                                id: "discussion-tab-pane",
                                                role: "tabpanel",
                                                "aria-labelledby": "discussion-tab",
                                                tabIndex: 0,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(eventDetails_DiscussionTab, {})
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row cus-mar friend-request",
                                children: eventData/* default.slice */.Z.slice(0, 3).map((itm)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-xl-4 col-sm-6 col-8",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(EventCard/* default */.Z, {
                                            data: itm
                                        })
                                    }, itm.id))
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const eventDetails_EventDetailsMain = (EventDetailsMain);

;// CONCATENATED MODULE: ./app/event/[eventId]/page.tsx


function EventDetails() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(eventDetails_EventDetailsMain, {})
    });
}


/***/ }),

/***/ 96683:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// components/common/NewsFeeds.tsx
/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/common/NewsFeeds.tsx");


/***/ }),

/***/ 95244:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// components/menu/HomeLeft.tsx
/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/components/menu/HomeLeft.tsx");


/***/ }),

/***/ 14969:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-2.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 60072:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-3.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 82688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar-4.f13b9673.png","height":48,"width":48,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAACVBMVEXu7u7z8/PU1NRSeSrpAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAHElEQVR4nGNgwAIYGRkZwQwmJiYmMAvOgEuhAQAD6wAbFbEoWAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 60640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/event-cover-img.fc9aecbe.png","height":500,"width":966,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAD1BMVEXz8/Pb29vCwsLV1dXt7e1xLeDOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAGklEQVR4nGNgYQADFgYGRiZmZiZGBgQDJgUAAvQAKbyR5DUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4859,1883,6721,9964,247,6922,9461,9524,8223,5678,7792], () => (__webpack_exec__(81983)));
module.exports = __webpack_exports__;

})();