(() => {
var exports = {};
exports.id = 2626;
exports.ids = [2626];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 95232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 36188:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(75183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(15815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(50515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'login',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56058)), "/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/login/page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45596)), "/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4756))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/login/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/login/page"
  

/***/ }),

/***/ 51549:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58895))

/***/ }),

/***/ 58895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ LoginPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/reactstrap/lib/index.js
var lib = __webpack_require__(34775);
// EXTERNAL MODULE: ./store/hooks.tsx
var hooks = __webpack_require__(39970);
// EXTERNAL MODULE: ./store/authSlice.tsx
var authSlice = __webpack_require__(76844);
// EXTERNAL MODULE: ./styles/custom.scss
var custom = __webpack_require__(64445);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/index.mjs + 1 modules
var dist = __webpack_require__(69964);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./components/signIn/signIn.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







function SignIn({ isRightPanelActive , setIsRightPanelActive  }) {
    const [showForgotPassword, setShowForgotPassword] = (0,react_.useState)(false);
    const [credential, setCredentials] = (0,react_.useState)({
        email: "",
        password: "",
        device_type: 1,
        device_token: "test",
        device_token_voip_ios: "test"
    });
    const [forgotpas, setForgotPas] = (0,react_.useState)("");
    const dispatch = (0,hooks/* useAppDispatch */.T)();
    const router = (0,navigation.useRouter)();
    const { loading , error , isAuthenticated  } = (0,hooks/* useAppSelector */.C)((state)=>state.auth);
    (0,react_.useEffect)(()=>{
        if (error) {
            dist/* toast.error */.Am.error(error);
            dispatch((0,authSlice/* clearError */.fw)());
        }
        if (isAuthenticated && !showForgotPassword) {
            dist/* toast.success */.Am.success("Login successful!");
            setCredentials({
                email: "",
                password: "",
                device_type: 1,
                device_token: "test",
                device_token_voip_ios: "test"
            });
            router.push("/dashboard");
        }
    }, [
        error,
        isAuthenticated,
        dispatch,
        showForgotPassword,
        router
    ]);
    const handleForgotPassword = (e)=>{
        e.preventDefault();
        if (forgotpas === "") {
            dist/* toast.warn */.Am.warn("Please enter your email");
            return;
        }
        dispatch((0,authSlice/* forgotPassword */.gF)(forgotpas)).then((result)=>{
            if (result.meta.requestStatus === "fulfilled") {
                dist/* toast.success */.Am.success("Password reset link sent!");
                setShowForgotPassword(false);
                setForgotPas("");
            }
        });
    };
    function userSubmitCredential(e) {
        const { name , value  } = e.target;
        setCredentials((previousEl)=>({
                ...previousEl,
                [name]: value
            }));
        dispatch((0,authSlice/* clearError */.fw)());
    }
    function onSubmitCredentials(e) {
        e.preventDefault();
        if (credential.email === "" || credential.password === "") {
            dist/* toast.warn */.Am.warn("Please fill all fields");
            return;
        }
        dispatch((0,authSlice/* loginUser */.pH)(credential)).then((result)=>{
            if (result.meta.requestStatus === "rejected") {
                console.error("Login failed:", result.payload);
            }
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `form-container sign-in ${isRightPanelActive ? "hidden" : ""}`,
        children: !showForgotPassword ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* Form */.l0, {
            onSubmit: onSubmitCredentials,
            className: "form",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    children: "Sign In"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: "or use your account"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                    name: "email",
                    onChange: userSubmitCredential,
                    value: credential.email,
                    type: "email",
                    placeholder: "Email",
                    className: "black-bg"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                    name: "password",
                    value: credential.password,
                    type: "password",
                    placeholder: "Password",
                    onChange: userSubmitCredential,
                    className: "black-bg"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "#",
                    onClick: ()=>setShowForgotPassword(true),
                    children: "Forgot your password?"
                }),
                error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "error",
                    children: error
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "button-group",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "submit",
                            className: "desktop-only",
                            disabled: loading,
                            children: loading ? "Signing In..." : "Sign In"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "button",
                            onClick: ()=>setIsRightPanelActive(true),
                            children: "Sign Up"
                        })
                    ]
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* Form */.l0, {
            onSubmit: handleForgotPassword,
            className: "form",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    children: "Forgot Password"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "description",
                    children: "Enter your email to receive a password reset link"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                    value: forgotpas,
                    onChange: (e)=>setForgotPas(e.target.value),
                    type: "email",
                    placeholder: "Email",
                    className: "black-bg"
                }),
                error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "error",
                    children: error
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "button-group btn-margin",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "button",
                            onClick: ()=>{
                                setShowForgotPassword(false);
                                dispatch((0,authSlice/* clearError */.fw)());
                            },
                            children: "Back"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "submit",
                            disabled: loading,
                            children: loading ? "Sending..." : "Send Link"
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/react-icons/fi/index.mjs + 4 modules
var fi = __webpack_require__(49377);
;// CONCATENATED MODULE: ./components/signup/signup.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








// Explicitly type the icons as React components
const FiEyeIcon = fi/* FiEye */.rDJ;
const FiEyeOffIcon = fi/* FiEyeOff */.rzC;
function SignUp({ isRightPanelActive  }) {
    const [showOtpForm, setShowOtpForm] = (0,react_.useState)(false);
    const [showPassword, setShowPassword] = (0,react_.useState)(false);
    const [showConfirmPassword, setShowConfirmPassword] = (0,react_.useState)(false);
    const [userProfile, setUserProfile] = (0,react_.useState)({
        username: "",
        email: "",
        password: "",
        current_password: "",
        phone: "1234567888",
        country_code: "+1",
        login_ip: "192.168.1.1",
        role: 3,
        device_type: "mobile",
        industry: "IT",
        location: "Bengaluru",
        bio: "Test is Test",
        website: "www.test.com",
        profile_category_type: 2,
        interest_id: "1,2,3,4,5"
    });
    const [otp, setOtp] = (0,react_.useState)("");
    const dispatch = (0,hooks/* useAppDispatch */.T)();
    const router = (0,navigation.useRouter)();
    const { loading , error , isAuthenticated  } = (0,hooks/* useAppSelector */.C)((state)=>state.auth);
    (0,react_.useEffect)(()=>{
        if (error) {
            dist/* toast.error */.Am.error(error);
            dispatch((0,authSlice/* clearError */.fw)());
        }
        if (isAuthenticated && showOtpForm) {
            dist/* toast.success */.Am.success("OTP verified successfully!");
            setUserProfile({
                username: "",
                email: "",
                password: "",
                current_password: "",
                phone: "1234567888",
                country_code: "+1",
                login_ip: "192.168.1.1",
                role: 3,
                device_type: "mobile",
                industry: "IT",
                location: "Bengaluru",
                bio: "Test is Test",
                website: "www.test.com",
                profile_category_type: 2,
                interest_id: "1,2,3,4,5"
            });
            setOtp("");
            setShowOtpForm(false);
            router.push("/dashboard");
        }
        if (!error && showOtpForm && !loading && !isAuthenticated) {
            dist/* toast.success */.Am.success("Signup successful! Please verify OTP.");
        }
    }, [
        error,
        isAuthenticated,
        showOtpForm,
        loading,
        dispatch,
        router
    ]);
    function userSubmitProfile(e) {
        const { name , value  } = e.target;
        setUserProfile((previousEl)=>({
                ...previousEl,
                [name]: value
            }));
        dispatch((0,authSlice/* clearError */.fw)());
    }
    function onSubmit(e) {
        e.preventDefault();
        if (userProfile.username === "" || userProfile.email === "" || userProfile.password === "" || userProfile.current_password === "") {
            dist/* toast.warn */.Am.warn("Please fill all fields");
            return;
        }
        if (userProfile.password !== userProfile.current_password) {
            dist/* toast.warn */.Am.warn("Passwords do not match");
            return;
        }
        const payload = {
            username: userProfile.username,
            email: userProfile.email,
            password: userProfile.password,
            phone: userProfile.phone,
            country_code: userProfile.country_code,
            login_ip: userProfile.login_ip,
            role: userProfile.role,
            device_type: userProfile.device_type,
            industry: userProfile.industry,
            location: userProfile.location,
            bio: userProfile.bio,
            website: userProfile.website,
            profile_category_type: userProfile.profile_category_type,
            interest_id: userProfile.interest_id
        };
        dispatch((0,authSlice/* registerUser */.a$)(payload)).then((result)=>{
            if (result.meta.requestStatus === "fulfilled") {
                setShowOtpForm(true);
            }
        });
    }
    function onSubmitOtp(e) {
        e.preventDefault();
        if (otp === "") {
            dist/* toast.warn */.Am.warn("Please enter OTP");
            return;
        }
        dispatch((0,authSlice/* verifyOtp */.Mu)({
            email: userProfile.email,
            otp
        }));
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `form-container sign-up ${isRightPanelActive ? "active" : ""}`,
        children: !showOtpForm ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* Form */.l0, {
            className: "form",
            onSubmit: onSubmit,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "margin-unset",
                    children: "Sign Up"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                    name: "username",
                    value: userProfile.username,
                    type: "text",
                    placeholder: "Username",
                    onChange: userSubmitProfile,
                    className: "black-bg"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                    name: "email",
                    value: userProfile.email,
                    type: "email",
                    placeholder: "Email",
                    onChange: userSubmitProfile,
                    className: "black-bg"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "password-container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                            name: "password",
                            value: userProfile.password,
                            type: showPassword ? "text" : "password",
                            placeholder: "Password",
                            onChange: userSubmitProfile,
                            className: "black-bg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            onClick: ()=>setShowPassword(!showPassword),
                            children: showPassword ? /*#__PURE__*/ jsx_runtime_.jsx(FiEyeOffIcon, {}) : /*#__PURE__*/ jsx_runtime_.jsx(FiEyeIcon, {})
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "password-container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                            name: "current_password",
                            value: userProfile.current_password,
                            type: showConfirmPassword ? "text" : "password",
                            placeholder: "Confirm Password",
                            onChange: userSubmitProfile,
                            className: "black-bg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            onClick: ()=>setShowConfirmPassword(!showConfirmPassword),
                            children: showConfirmPassword ? /*#__PURE__*/ jsx_runtime_.jsx(FiEyeOffIcon, {}) : /*#__PURE__*/ jsx_runtime_.jsx(FiEyeIcon, {})
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "checkbox-container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                            type: "checkbox",
                            id: "terms",
                            required: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(lib/* Label */.__, {
                            htmlFor: "terms",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "custom-style",
                                children: [
                                    "By Signing up, you are acknowledging that you have read, understood and accept our",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "link custom-style-a",
                                        href: "#",
                                        children: "Terms of Service"
                                    }),
                                    " ",
                                    "and",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "link custom-style-a",
                                        href: "#",
                                        children: "Privacy policy"
                                    })
                                ]
                            })
                        })
                    ]
                }),
                error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "error",
                    children: error
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "button-group",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        type: "submit",
                        disabled: loading,
                        children: loading ? "Requesting..." : "Request OTP"
                    })
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* Form */.l0, {
            className: "form",
            onSubmit: onSubmitOtp,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    children: "Verify OTP"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "description",
                    children: "Enter the OTP received on your email"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib/* Input */.II, {
                    className: "black-bg",
                    value: otp,
                    type: "text",
                    placeholder: "Enter OTP",
                    onChange: (e)=>setOtp(e.target.value)
                }),
                error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "error",
                    children: error
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "button-group btn-margin",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "button",
                            onClick: ()=>{
                                setShowOtpForm(false);
                                dispatch((0,authSlice/* clearError */.fw)());
                            },
                            children: "Back"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "submit",
                            disabled: loading,
                            children: loading ? "Verifying..." : "Verify"
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./public/images/logo.png
var logo = __webpack_require__(59374);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(1536);
;// CONCATENATED MODULE: ./app/login/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








function LoginPage() {
    const [isRightPanelActive, setIsRightPanelActive] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `panel-container ${isRightPanelActive ? "right-panel-active" : ""}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(SignUp, {
                        isRightPanelActive: isRightPanelActive
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SignIn, {
                        isRightPanelActive: isRightPanelActive,
                        setIsRightPanelActive: setIsRightPanelActive
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `overlay ${isRightPanelActive ? "-translate-x-full" : ""}`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `overlay-content ${isRightPanelActive ? "translate-x-1/2" : ""}`,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: `panel left ${isRightPanelActive ? "active" : ""}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: logo/* default */.Z,
                                            alt: "TechSocial Logo",
                                            width: 300,
                                            height: 80
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "text-black",
                                            children: "Welcome Back!"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-black",
                                            children: "To keep connected with us please login with your personal info"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "action-btn",
                                            onClick: ()=>setIsRightPanelActive(false),
                                            children: "Sign In"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: `panel right ${isRightPanelActive ? "" : ""}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: logo/* default */.Z,
                                            alt: "TechSocial Logo",
                                            width: 300,
                                            height: 80
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "text-black",
                                            children: "Hello, Friend!"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-black",
                                            children: "Enter your personal details and start journey with us"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "action-btn",
                                            onClick: ()=>setIsRightPanelActive(true),
                                            children: "Sign Up"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dist/* ToastContainer */.Ix, {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                newestOnTop: false,
                closeOnClick: true,
                rtl: false,
                pauseOnFocusLoss: true,
                draggable: true,
                pauseOnHover: true,
                theme: "dark"
            })
        ]
    });
}


/***/ }),

/***/ 39970:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ useAppSelector),
/* harmony export */   "T": () => (/* binding */ useAppDispatch)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1560);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

const useAppDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)();
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;


/***/ }),

/***/ 56058:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/twlight/Documents/Company-Project/techsocial-web-app/Tech-social-app/app/login/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);


/***/ }),

/***/ 64445:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4859,1883,9964,6071,3894,5774,247], () => (__webpack_exec__(36188)));
module.exports = __webpack_exports__;

})();